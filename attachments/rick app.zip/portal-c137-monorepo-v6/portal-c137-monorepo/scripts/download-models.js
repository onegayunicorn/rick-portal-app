#!/usr/bin/env node
// Download quantized offline AI weights and 3D assets into apps/web/public/models/.
// Run: pnpm run download:models
const fs = require("fs");
const path = require("path");

const MODELS_DIR = path.join(__dirname, "..", "apps", "web", "public", "models");
const ASSETS = [
  {
    name: "Llama-3.2-1B-Instruct-q4f16_1-MLC (WebLLM)",
    url: "https://huggingface.co/mlc-ai/Llama-3.2-1B-Instruct-q4f16_1-MLC/resolve/main/",
    note: "Download full model directory from HuggingFace (~700MB)",
  },
  {
    name: "whisper-tiny-en (Xenova Transformers)",
    url: "https://huggingface.co/Xenova/whisper-tiny-en/resolve/main/",
    note: "Download ONNX quantized weights (~40MB)",
  },
  {
    name: "rick_portal_gun.glb (3D asset)",
    note: "Place your DRACO/Meshopt compressed GLB model here (<2MB recommended)",
  },
];

async function main() {
  fs.mkdirSync(MODELS_DIR, { recursive: true });
  console.log("[Portal] Sovereign model downloader");
  console.log("[Portal] Target directory: " + MODELS_DIR);
  console.log("");
  ASSETS.forEach((a, i) => {
    console.log((i + 1) + ". " + a.name);
    if (a.url) console.log("   URL:  " + a.url);
    console.log("   Note: " + a.note);
    console.log("");
  });
  console.log("[Portal] Due to file sizes, download each asset manually from the URLs above.");
  console.log("[Portal] Place extracted weights directly in apps/web/public/models/.");
}

main().catch(console.error);
