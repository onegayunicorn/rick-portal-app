# 🔫 Sovereign AI Portal Interface & Video Engine

**Master Production Monorepo · Revision 6.0.0**
*Sovereign Monorepo, Offline WebGPU AI, 3D GLTF/VRM Avatar, Hardened Native Bridge & Multi-Cloud Deployment*

> *"Portal test complete. Structure stable. You're clear to proceed."*

A sovereign, zero-vendor-lock-in monorepo uniting interactive video pipelines, 3D WebGL/VRM avatar
kinematics (two-bone IK, viseme lip-sync, screen-to-world pointing), semantic AI audio-to-gesture
mapping, offline WebGPU neural inference, hardened native OS hardware bridges (HMAC-SHA256
zero-trust), and multi-cloud / cross-platform deployment (PWA, Docker, Vercel, Cloudflare, Tauri,
Android APK, PortableApps.com PAF).

## AI-to-Visual & Kinematic Mapping Pipeline

1. AI Engine (WebLLM / Qwen2.5-0.5B WebGPU) → Structured Output (Tokens, SSML, Gesture Tags)
2. Acoustic & Phoneme Parser → Viseme Extraction (60fps LERP with exponential decay)
3. Inverse Kinematics Engine → Screen-to-World 2D-to-3D Target Projection
4. Layered Animation Blender → Base Idle + Saccades + Semantic IK + Hand Poses
5. Three.js / VRM Render Loop → Synchronized Canvas / Holographic HUD Display

## Monorepo Layout

- `apps/web` — React 19 + Vite PWA (InteractiveVideoStage, PortalShaderCanvas, AvatarKinematicsStage, InstallPwaBanner, MasterRenderLoop, lib: ai-semantic-mapper / offline-webgpu-llm / two-bone-ik / hardened-bridge-client)
- `apps/api-edge` — Hono Edge microservice (Gist + Matrix proxies)
- `apps/desktop-tauri` — Tauri v2 (Rust) desktop wrapper
- `apps/mobile-capacitor` — Capacitor 6 iOS/Android wrapper
- `apps/android-native` — Hardened Kotlin shell (com.rickc137.portal)
- `apps/native-android` — Sovereign Native Android Shell (dev.sovereign.portal, SovereignAndroidBridge)
- `apps/portable-builder` — Tkinter 5-panel PAF builder UI
- `packages/graphics-engine` — Three.js/R3F + CoordinateProjector + TwoBoneIK + VisemeBlender
- `packages/database` — Dual ORM (Prisma v6 + Drizzle with telemetryEvents/interactiveCues/syncLogs)
- `packages/gist-sync` — GitHub Gist export/import
- `packages/offline-ai` — WebLLM Llama-3.2 + Whisper STT + Kokoro TTS
- `packages/hud-overlay-system` — Cybernetic HUD widgets
- `packages/matrix-protocol` — Matrix E2EE (Olm/Megolm) twin sync
- `packages/video-engine` — rVFC frame-accurate sync + HardenedBridgeClient
- `packages/ui-core` — Tailwind preset, tokens, sound FX
- `packages/tsconfig` — Base TS configs
- `docker/` — Multi-stage Dockerfile (nginx:1.27-alpine-slim, USER nginx, port 8080), hardened nginx.conf, docker-compose.yml
- `standalone-html/` — Zero-build single-file index.html
- `portable-app/` — PortableApps.com (PAF) structure
- `tools/`, `scripts/`, `docs/` — Build helpers & deployment/verification docs

## Quick Start

```bash
pnpm install          # Node >=20.18, pnpm >=9.0
pnpm run dev          # Parallel dev servers
pnpm run build        # Production build (turborepo cached)
pnpm run download:models  # Fetch offline AI weights
```

## Deployment

| Target | Command |
| :--- | :--- |
| Vercel Edge | `pnpm dlx vercel --prod` |
| Cloudflare Pages | `wrangler pages deploy apps/web/dist` |
| Sovereign Docker | `docker compose -f docker/docker-compose.yml up -d --build` |
| Desktop (Tauri) | `cd apps/desktop-tauri && pnpm tauri build` |
| Android Native APK | `cd apps/native-android && ./gradlew assembleRelease` |
| PortableApp (PAF) | `python3 apps/portable-builder/builder_ui.py` |
| Standalone HTML | Open `standalone-html/index.html` |

## Verification Matrix

- AI-to-Gesture: JSON cues align with audio timestamps (< 20ms offset)
- Screen-to-World Projection: raycast unprojection hits within 5% of DOM center
- Two-Bone Arm IK: Law of Cosines valid elbow angle, no gimbal lock
- Sub-Frame Video Sync: rVFC within 16.6ms frame delta
- Zero-Trust Bridge: rejects expired timestamps and forged nonces
- PWA Installation: Kyrexis banner registers sw.js and fires native prompt
