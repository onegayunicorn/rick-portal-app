# AI Answer-to-Gesture & Visual Interface Mapping Matrix

Maps semantic conversation states, vocal intonations, and HUD telemetry triggers
directly to avatar physiological and kinematic responses.

| Verbal / Cognitive Intent | Phoneme / Viseme State | Facial Emotion Blendshape | Gaze Target (LookAt) | Left Hand Pose & Arm IK | Right Hand Pose & Arm IK | HUD Telemetry State |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Greeting / Awakening** | Initial silence to open vowels (`viseme_aa`) | `happy: 0.6`, `browInnerUp: 0.4` | User screen center `(0, 0, 1.5)` | Relaxed natural hang at hip | Wave right hand (`wave_right_hand`), palm facing viewer | `ORCHESTRATOR ONLINE` green badge pulse |
| **Explaining Telemetry** | Rapid consonant/vowel alternation (`viseme_DD`, `viseme_nn`) | `neutral: 0.8`, `eyeSquint: 0.2` | Telemetry Card `(x_hud, y_hud, z_world)` | Rest on hip or open palm support | Extend index finger towards Telemetry Card via Two-Bone IK | Highlight `RESONANCE 1207 Hz` card border |
| **Dimension Alert / Danger** | Staccato plosives (`viseme_PP`, `viseme_TH`) | `angry: 0.4`, `browDown: 0.7` | Reticle / Coordinate Tag `(x_dim, y_dim)` | Clenched fist (`pose_fist`), tension 0.8 | Open palm sweep towards collapse button | `STABILITY: 99.8%` flashes alert red `#ff0055` |
| **Deliberating / Computing** | Closed mouth (`viseme_sil`), micro-breathing | `browInnerUp: 0.6`, `mouthShrug: 0.3` | Upward saccadic drift `(0.2, 0.8, 1.0)` | Open palm chest level (`pose_relaxed`) | Index finger tapped to temple (`pose_point`) | Audio visualizer switches to processing pulse |
| **Presenting Choice / Branch** | Broad vowels (`viseme_O`, `viseme_E`) | `smile: 0.5`, `eyesWide: 0.3` | Branching dialogue modal | Open palm up pointing to Option A (`palms_up`) | Open palm up pointing to Option B (`palms_up`) | Render interactive branch buttons in DOM overlay |
| **Portal Gun Discharge** | Sibilant exhale (`viseme_SS`) | `intenseFocus: 0.9` | 3D Portal Vortex center `(0, 0, -2.0)` | Supporting barrel of Portal Gun | Clenched grip on portal trigger (`pose_grip`) | WebGL accretion disk velocity expands 300% |

## Kinetic & Mathematical Algorithms

### Screen-to-World Coordinate Projection
```
p_screen = [ (x_DOM + w/2)/W_viewport * 2 - 1, -(y_DOM + h/2)/H_viewport * 2 + 1, z_depth ]
p_world  = M_proj^-1 * M_view^-1 * p_screen
```
Implementation: `packages/graphics-engine/src/CoordinateProjection.ts`

### Two-Bone Analytical IK (Law of Cosines)
```
cos(theta_elbow) = (||T - S||^2 - L1^2 - L2^2) / (2 * L1 * L2)
```
Implementation: `packages/graphics-engine/src/TwoBoneIK.ts`

### Viseme Exponential Smoothing
```
V_t = V_{t-1} + (V_target - V_{t-1}) * (1 - e^(-lambda * delta_t))
```
Implementation: `packages/graphics-engine/src/VisemeBlender.ts` (lambda = 18.0)

## AI-to-Visual & Kinematic Mapping Pipeline

1. AI Engine (WebLLM / Cloud) -> Structured Output (Tokens, SSML, Gesture Tags)
2. Acoustic & Phoneme Parser -> Viseme Extraction (OVR / Rhubarb 60fps LERP)
3. Inverse Kinematics Engine -> Screen-to-World 2D-to-3D Target Projection
4. Layered Animation Blender -> Base Idle + Saccades + Semantic IK + Hand Poses
5. Three.js / VRM Render Loop -> Synchronized Canvas / Holographic HUD Display
