# Verification & Zero-Failure Checklist

## Sovereign Monorepo

1. **WebGPU Availability:** Verify `navigator.gpu` status; fallback gracefully to WebGL2 shaders if absent.
2. **Model Weights Offline Caching:** Verify Service Worker serves quantized weights from CacheStorage and executes local inference.
3. **Shader Performance:** Ensure `portal.frag` runs at steady 60 FPS on mobile GPUs (Adreno 6xx/7xx, Apple Silicon).
4. **HUD Alignment:** Telemetry status cards, dimension coordinates (1207), and prompt capsules maintain proportional responsive scaling.
5. **Security & Zero Telemetry:** CSP blocks external outbound analytics or unauthorized cloud endpoints.

## Master System Verification Matrix

| Subsystem | Requirement | Verification Method |
| :--- | :--- | :--- |
| Video Sync Engine | Frame-accurate cue triggers | `requestVideoFrameCallback` within 16.6ms frame delta |
| Sovereign Shell | Zero CORS asset loading | Android `WebViewAssetLoader` intercepts `https://appassets...` |
| PWA Converter | Standalone PWA generator | Injects `<link rel="manifest">` and offline `sw.js` |
| PAF Packaging | Air-gapped portability | Runs from USB, zero leftover registry or `%APPDATA%` keys |
| WebGPU Offline AI | Zero remote API calls | Llama 3.2 1B & Whisper STT execute locally via WebGPU/WASM |
| Dual ORM Sync | Edge-to-Cloud persistence | Drizzle (local SQLite) background batches push to Prisma |
| Zero-Trust Bridge | Anti-replay & signature | Forged payload returns `REPLAY_DETECTED` / `INVALID_SIGNATURE` |
| GOP Keyframe Integrity | Closed GOPs + faststart | `ffprobe` confirms `-sc_threshold 0` and moov atom at start |
