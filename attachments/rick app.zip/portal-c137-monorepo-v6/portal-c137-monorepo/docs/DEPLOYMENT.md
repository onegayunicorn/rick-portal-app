# Production Deployment Guide (Rev 6.0)

## Complete Execution & Verification Runbook

```bash
# 1. Monorepo Setup & Dependency Installation
pnpm install

# 2. Local Development Server
pnpm dev

# 3. Production Compilation & Bundle Optimization
pnpm build

# 4. Multi-Stage Docker Containerization (rev 6.0: docker/ directory)
docker build -t sovereign-portal:v1.0.0 -f docker/Dockerfile .
docker compose -f docker/docker-compose.yml up -d

# 5. PortableApps Spec 1.0 Packaging (tkinter GUI)
python3 apps/portable-builder/builder_ui.py

# 6. Vercel Production Deployment
cd apps/web && vercel --prod

# 7. Android Native APK (Hardened Kotlin Shell)
cd apps/native-android && ./gradlew assembleRelease

# 8. Desktop (Tauri v2)
cd apps/desktop-tauri && pnpm tauri build
```

## Video Authoring (FFmpeg Transcoding)

```bash
ffmpeg -i VID_source.mp4 \
  -c:v libx264 -profile:v high -level:v 4.2 -preset slow -crf 20 \
  -r 30 -g 30 -keyint_min 30 -sc_threshold 0 \
  -pix_fmt yuv420p -colorspace bt709 -color_primaries bt709 -color_trc bt709 \
  -movflags +faststart \
  -c:a aac -b:a 192k -ar 48000 \
  -y apps/web/public/media/portal-stream.mp4
```

## Deployment Target Matrix

| Target | Command | Cold Start |
| :--- | :--- | :--- |
| Vercel Edge | `pnpm dlx vercel --prod` | < 50ms |
| Cloudflare Pages | `wrangler pages deploy .` | < 25ms |
| GitHub Pages | Automated GitHub Action | < 100ms |
| Sovereign Docker | `docker compose -f docker/docker-compose.yml up -d` | < 10ms |
| Android Native APK | `./gradlew assembleRelease` | Instant |
| iOS Native Shell | `xcodebuild -archive` | Instant |
| Desktop (Tauri v2) | `pnpm tauri build` | Instant |
| PortableApps (PAF) | `python3 apps/portable-builder/builder_ui.py` | Instant |
