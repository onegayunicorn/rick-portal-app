import React from "react";

/** CRT scanline & chromatic aberration overlay (pure CSS, zero cost). */
export function ScanlineFilter() {
  return (
    <>
      <div
        className="scanlines absolute top-0 left-0 w-full h-full"
        style={{ zIndex: 2 }}
      />
      <div
        className="absolute top-0 left-0 w-full h-full pointer-events-none"
        style={{
          zIndex: 3,
          background:
            "radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.55) 100%)",
          mixBlendMode: "multiply",
        }}
      />
    </>
  );
}
