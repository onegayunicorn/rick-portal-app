import React, { useEffect, useState } from "react";

interface TerminalPromptProps {
  text: string;
  speed?: number; // ms per char
  onComplete?: () => void;
}

/** Typewriter terminal prompt effect. */
export function TerminalPrompt({ text, speed = 25, onComplete }: TerminalPromptProps) {
  const [displayed, setDisplayed] = useState("");

  useEffect(() => {
    setDisplayed("");
    let i = 0;
    const interval = setInterval(() => {
      i++;
      setDisplayed(text.slice(0, i));
      if (i >= text.length) {
        clearInterval(interval);
        onComplete?.();
      }
    }, speed);
    return () => clearInterval(interval);
  }, [text, speed, onComplete]);

  return (
    <div
      className="text-[13px] leading-relaxed min-h-[50px]"
      style={{ color: "#fff", textShadow: "0 0 4px rgba(255,255,255,0.4)" }}
    >
      {displayed}
      <span style={{ animation: "pulse 1s infinite" }}>▌</span>
    </div>
  );
}
