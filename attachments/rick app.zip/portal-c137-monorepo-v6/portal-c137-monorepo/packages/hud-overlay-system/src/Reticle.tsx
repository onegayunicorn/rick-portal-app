import React from "react";

/** Cybernetic corner-bracket target reticle overlay. */
export function Reticle({ x = 50, y = 50, size = 40 }: { x?: number; y?: number; size?: number }) {
  const half = size / 2;
  const arm = size * 0.35;
  const color = "#00ff88";
  return (
    <svg
      className="absolute pointer-events-none"
      style={{ left: `${x}%`, top: `${y}%`, transform: "translate(-50%, -50%)", zIndex: 5 }}
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
    >
      {/* Four corner brackets */}
      <path d={`M0 ${arm} L0 0 L${arm} 0`} stroke={color} strokeWidth="1.5" fill="none" />
      <path d={`M${size - arm} 0 L${size} 0 L${size} ${arm}`} stroke={color} strokeWidth="1.5" fill="none" />
      <path d={`M${size} ${size - arm} L${size} ${size} L${size - arm} ${size}`} stroke={color} strokeWidth="1.5" fill="none" />
      <path d={`M${arm} ${size} L0 ${size} L0 ${size - arm}`} stroke={color} strokeWidth="1.5" fill="none" />
      {/* Center crosshair */}
      <line x1={half} y1={half - 4} x2={half} y2={half + 4} stroke={color} strokeWidth="1" />
      <line x1={half - 4} y1={half} x2={half + 4} y2={half} stroke={color} strokeWidth="1" />
    </svg>
  );
}
