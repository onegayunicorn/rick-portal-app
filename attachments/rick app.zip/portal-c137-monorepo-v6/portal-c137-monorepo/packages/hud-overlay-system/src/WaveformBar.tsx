import React, { useEffect, useRef } from "react";

interface WaveformBarProps {
  analyser: AnalyserNode | null;
  height?: number;
}

/** Real-time WebAudio frequency analyzer (oscilloscope / waveform visualizer). */
export function WaveformBar({ analyser, height = 24 }: WaveformBarProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let raf = 0;
    const dataArray = analyser ? new Uint8Array(analyser.frequencyBinCount) : null;

    const draw = () => {
      raf = requestAnimationFrame(draw);
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      ctx.fillStyle = "rgba(2,20,9,0.8)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      if (analyser && dataArray) {
        analyser.getByteFrequencyData(dataArray);
        const barWidth = canvas.width / dataArray.length;
        for (let i = 0; i < dataArray.length; i++) {
          const h = (dataArray[i] / 255) * canvas.height;
          ctx.fillStyle = i % 2 === 0 ? "#00ff88" : "#d4ff00";
          ctx.fillRect(i * barWidth, canvas.height - h, barWidth - 1, h);
        }
      }
    };
    draw();
    return () => cancelAnimationFrame(raf);
  }, [analyser]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        width: "100%",
        height,
        marginTop: 8,
        background: "rgba(0,0,0,0.3)",
        border: "1px solid var(--hud-border)",
      }}
    />
  );
}
