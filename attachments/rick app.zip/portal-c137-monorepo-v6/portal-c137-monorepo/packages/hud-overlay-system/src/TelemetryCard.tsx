import React from "react";

interface TelemetryCardProps {
  label: string;
  value: string | number;
  unit?: string;
  accent?: "green" | "cyan" | "yellow" | "alert";
}

const accentMap = {
  green: "#00ff88",
  cyan: "#00e5ff",
  yellow: "#d4ff00",
  alert: "#ff0055",
};

export function TelemetryCard({ label, value, unit, accent = "green" }: TelemetryCardProps) {
  const color = accentMap[accent];
  return (
    <div
      className="px-3 py-2 rounded"
      style={{
        background: "rgba(2,18,8,0.6)",
        border: `1px solid ${color}55`,
        minWidth: 90,
      }}
    >
      <div className="text-[9px] uppercase tracking-widest opacity-70" style={{ color }}>
        {label}
      </div>
      <div className="text-sm font-bold" style={{ color, textShadow: `0 0 6px ${color}` }}>
        {value}
        {unit && <span className="text-[10px] ml-1 opacity-70">{unit}</span>}
      </div>
    </div>
  );
}
