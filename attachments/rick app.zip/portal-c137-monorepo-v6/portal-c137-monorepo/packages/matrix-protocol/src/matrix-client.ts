import * as sdk from "matrix-js-sdk";

/**
 * Matrix client with Olm/Megolm end-to-end encryption.
 * Every user instance holds an Ed25519 key pair locally in IndexedDB / WebCrypto.
 * Zero central tracking - runs against self-hosted Dendrite/Conduit servers.
 */
export class MatrixPortalClient {
  private client: any = null;
  private homeserver: string;

  constructor(homeserver = process.env.MATRIX_HOMESERVER_URL || "http://localhost:8448") {
    this.homeserver = homeserver;
  }

  async login(userId: string, accessToken: string) {
    this.client = sdk.createClient({
      baseUrl: this.homeserver,
      accessToken,
      userId,
      deviceId: `PORTAL_C137_${Math.random().toString(36).slice(2, 10).toUpperCase()}`,
    });
    await this.client.initCrypto();
    await this.client.startClient({ initialSyncLimit: 10 });
    return this.client;
  }

  async joinTwinRoom(roomId = "!dimension-c137:sovereign.mesh") {
    if (!this.client) throw new Error("Matrix client not logged in");
    await this.client.joinRoom(roomId);
    return roomId;
  }

  getClient() {
    return this.client;
  }
}
