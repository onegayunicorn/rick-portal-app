uniform float u_time;
uniform float u_resonance;
uniform vec3 u_color;
varying vec2 vUv;

void main() {
  float pulse = sin(vUv.y * 20.0 - u_time * 3.0 + u_resonance * 0.01) * 0.5 + 0.5;
  vec3 col = u_color * (0.6 + pulse * 0.8);
  gl_FragColor = vec4(col, 0.9);
}
