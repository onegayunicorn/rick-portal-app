import React, { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { useGLTF } from "@react-three/drei";
import * as THREE from "three";

interface PortalGunProps {
  resonance: number; // Audio resonance frequency (0.0 - 1.0)
  firing: boolean;
}

export function PortalGunModel({ resonance, firing }: PortalGunProps) {
  // Load 3D GLB model asset
  const { scene, materials } = useGLTF("/models/rick_portal_gun.glb") as any;
  const gunRef = useRef<THREE.Group>(null);
  const fluidMaterialRef = useRef<THREE.ShaderMaterial>(null);

  // Floating idle animation + firing recoil
  useFrame((state) => {
    if (!gunRef.current) return;
    const time = state.clock.getElapsedTime();
    gunRef.current.position.y = Math.sin(time * 2.0) * 0.05 + (firing ? -0.1 : 0);
    gunRef.current.rotation.z = Math.sin(time * 1.5) * 0.02;

    // Pulse internal portal fluid emission based on resonance
    if (materials["PortalLiquid"]) {
      materials["PortalLiquid"].emissiveIntensity = 2.0 + resonance * 5.0;
      materials["PortalLiquid"].emissive = new THREE.Color(
        firing ? 0xffcc00 : 0x00ff88
      );
    }
  });

  return (
    <group ref={gunRef} scale={[1.8, 1.8, 1.8]} position={[0, -0.6, 0]}>
      <primitive object={scene} />
    </group>
  );
}

useGLTF.preload("/models/rick_portal_gun.glb");
