import React from "react";
import { EffectComposer, Bloom, ChromaticAberration, Scanline } from "@react-three/postprocessing";
import { BlendFunction } from "postprocessing";
import * as THREE from "three";

export function GraphicsPipelineEffects({ active }: { active: boolean }) {
  if (!active) return null;
  return (
    <EffectComposer>
      {/* Rick Portal Neon Glow */}
      <Bloom
        intensity={1.5}
        luminanceThreshold={0.2}
        luminanceSmoothing={0.9}
        blendFunction={BlendFunction.SCREEN}
      />
      {/* Dimensional Aberration */}
      <ChromaticAberration
        offset={new THREE.Vector2(0.002, 0.002)}
        radialModulation={false}
        modulationOffset={0.15}
      />
      {/* Holographic Scanlines */}
      <Scanline
        blendFunction={BlendFunction.OVERLAY}
        density={2.5}
        opacity={0.12}
      />
    </EffectComposer>
  );
}
