import * as THREE from "three";

/**
 * Screen-to-World Coordinate Projection Engine.
 * Transforms 2D DOM/HUD bounding boxes into 3D world-space target vectors
 * for avatar gaze and inverse kinematics (IK) pointing.
 *
 *   p_screen = [ (x_DOM + w/2)/W_viewport * 2 - 1, -(y_DOM + h/2)/H_viewport * 2 + 1, z_depth ]
 *   p_world  = M_proj^-1 * M_view^-1 * p_screen
 */
export class CoordinateProjector {
  private camera: THREE.PerspectiveCamera;

  constructor(camera: THREE.PerspectiveCamera) {
    this.camera = camera;
  }

  /** Project a DOM element's center into 3D world space at a given depth plane. */
  domElementToWorldTarget(domElement: HTMLElement, targetZ = 0.5): THREE.Vector3 {
    const rect = domElement.getBoundingClientRect();
    const xCenter = rect.left + rect.width / 2;
    const yCenter = rect.top + rect.height / 2;
    const ndcX = (xCenter / window.innerWidth) * 2 - 1;
    const ndcY = -(yCenter / window.innerHeight) * 2 + 1;
    const ndcVector = new THREE.Vector3(ndcX, ndcY, 0.5);
    ndcVector.unproject(this.camera);
    // Calculate intersection with target plane at targetZ
    const dir = ndcVector.sub(this.camera.position).normalize();
    const distance = (targetZ - this.camera.position.z) / dir.z;
    return this.camera.position.clone().add(dir.multiplyScalar(distance));
  }

  /** Project percentage-based screen coords (0-100) to world space. */
  percentToWorld(xPercent: number, yPercent: number, targetZ = 0.5): THREE.Vector3 {
    const ndcX = (xPercent / 100) * 2 - 1;
    const ndcY = -(yPercent / 100) * 2 + 1;
    const vector = new THREE.Vector3(ndcX, ndcY, 0.5);
    vector.unproject(this.camera);
    const dir = vector.sub(this.camera.position).normalize();
    const distance = (targetZ - this.camera.position.z) / dir.z;
    return this.camera.position.clone().add(dir.multiplyScalar(distance));
  }
}
