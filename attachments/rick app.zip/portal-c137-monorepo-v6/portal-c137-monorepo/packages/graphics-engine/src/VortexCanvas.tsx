import React, { useEffect, useRef } from "react";

interface VortexCanvasProps {
  resonance: number;
  analyser: AnalyserNode | null;
}

/**
 * Audio-reactive WebGL portal vortex shader background.
 * Falls back to a CSS radial gradient if WebGL is unavailable.
 */
export function VortexCanvas({ resonance, analyser }: VortexCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const resonanceRef = useRef(resonance);
  resonanceRef.current = resonance;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const gl = canvas.getContext("webgl");
    if (!gl) {
      console.warn("[Portal] WebGL unavailable - using CSS fallback background.");
      return;
    }

    const resize = () => {
      canvas.width = canvas.parentElement?.clientWidth || 440;
      canvas.height = canvas.parentElement?.clientHeight || 880;
      gl.viewport(0, 0, canvas.width, canvas.height);
    };
    resize();
    window.addEventListener("resize", resize);

    const vsSource = `
      attribute vec2 a_position;
      void main() { gl_Position = vec4(a_position, 0.0, 1.0); }
    `;

    const fsSource = `
      precision highp float;
      uniform vec2 u_resolution;
      uniform float u_time;
      uniform float u_resonance;

      float hash(vec2 p) {
        p = fract(p * vec2(123.34, 456.21));
        p += dot(p, p + 45.32);
        return fract(p.x * p.y);
      }
      float noise(vec2 p) {
        vec2 i = floor(p);
        vec2 f = fract(p);
        f = f * f * (3.0 - 2.0 * f);
        return mix(
          mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
          mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x),
          f.y
        );
      }
      void main() {
        vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.x, u_resolution.y);
        float dist = length(uv);
        float angle = atan(uv.y, uv.x);
        float warp = 3.2 * sin(dist * 7.0 - u_time * 2.8 + u_resonance * 0.005);
        float spiral = angle + warp / (dist + 0.18);
        vec2 p = vec2(dist * 4.0 - u_time * 0.8, spiral * 2.0 / 3.14159);
        float n = noise(p) * 0.7 + noise(p * 2.5 + u_time * 0.4) * 0.3;
        vec3 col_void = vec3(0.01, 0.04, 0.02);
        vec3 col_core = vec3(0.0, 1.0, 0.53);
        vec3 col_accent = vec3(0.83, 1.0, 0.0);
        float rim = smoothstep(0.72, 0.22, dist);
        float glow = exp(-dist * 4.2) * 1.5;
        vec3 color = mix(col_void, col_core, n * rim) + col_accent * glow;
        gl_FragColor = vec4(color, 1.0);
      }
    `;

    const createShader = (type: number, source: string) => {
      const s = gl.createShader(type)!;
      gl.shaderSource(s, source);
      gl.compileShader(s);
      return s;
    };

    const program = gl.createProgram()!;
    gl.attachShader(program, createShader(gl.VERTEX_SHADER, vsSource));
    gl.attachShader(program, createShader(gl.FRAGMENT_SHADER, fsSource));
    gl.linkProgram(program);
    gl.useProgram(program);

    const posBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, posBuffer);
    gl.bufferData(
      gl.ARRAY_BUFFER,
      new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]),
      gl.STATIC_DRAW
    );
    const posAttr = gl.getAttribLocation(program, "a_position");
    gl.enableVertexAttribArray(posAttr);
    gl.vertexAttribPointer(posAttr, 2, gl.FLOAT, false, 0, 0);

    const uRes = gl.getUniformLocation(program, "u_resolution");
    const uTime = gl.getUniformLocation(program, "u_time");
    const uResonance = gl.getUniformLocation(program, "u_resonance");

    const startTime = performance.now();
    let raf = 0;
    const render = (now: number) => {
      gl.uniform2f(uRes, canvas.width, canvas.height);
      gl.uniform1f(uTime, (now - startTime) * 0.001);
      gl.uniform1f(uResonance, resonanceRef.current);
      gl.drawArrays(gl.TRIANGLES, 0, 6);
      raf = requestAnimationFrame(render);
    };
    raf = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute top-0 left-0 w-full h-full pointer-events-none"
      style={{ zIndex: 1 }}
    />
  );
}
