/**
 * Phoneme-to-Viseme Interpolation & Smoothing.
 * Visemes extracted from TTS audio are sampled at 60fps and linearly
 * interpolated with exponential decay to eliminate robotic snapping:
 *   V_t = V_{t-1} + (V_target - V_{t-1}) * (1 - e^(-lambda * delta_t))
 */
export class VisemeBlender {
  private currentWeights: Record<string, number> = {};
  private smoothingFactor = 18.0; // Decay lambda

  update(
    targets: Record<string, number>,
    delta: number,
    vrmAvatar: any
  ): void {
    for (const [viseme, targetWeight] of Object.entries(targets)) {
      const prev = this.currentWeights[viseme] || 0.0;
      const smoothed =
        prev + (targetWeight - prev) * (1 - Math.exp(-this.smoothingFactor * delta));
      this.currentWeights[viseme] = smoothed;
      // Apply to VRM blendshape proxy
      if (vrmAvatar?.expressionManager) {
        vrmAvatar.expressionManager.setValue(viseme, smoothed);
      }
    }
  }

  getWeights(): Record<string, number> {
    return { ...this.currentWeights };
  }

  reset(): void {
    this.currentWeights = {};
  }
}
