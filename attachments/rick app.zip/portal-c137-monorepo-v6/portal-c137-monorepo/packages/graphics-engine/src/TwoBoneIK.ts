import * as THREE from "three";

/**
 * Two-Bone Analytical Inverse Kinematics (Arm Reaching).
 * Applies two-bone analytical trigonometry (Law of Cosines) for realistic
 * arm extension towards HUD elements without numerical solver lag.
 *
 * Given upper arm length L1, forearm length L2, shoulder origin S, target T:
 *   cos(theta_elbow) = (||T - S||^2 - L1^2 - L2^2) / (2 * L1 * L2)
 */
export function solveTwoBoneIK(
  shoulder: THREE.Vector3,
  target: THREE.Vector3,
  l1: number,
  l2: number,
  _poleVector: THREE.Vector3
): { elbowAngle: number; shoulderRotation: THREE.Quaternion } {
  const toTarget = target.clone().sub(shoulder);
  const distance = Math.min(Math.max(toTarget.length(), 0.01), (l1 + l2) * 0.999);

  // Law of Cosines for elbow angle
  const cosElbow = (distance * distance - l1 * l1 - l2 * l2) / (2 * l1 * l2);
  const elbowAngle = Math.acos(Math.min(Math.max(cosElbow, -1.0), 1.0));

  // Shoulder angle offset
  const cosShoulder = (l1 * l1 + distance * distance - l2 * l2) / (2 * l1 * distance);
  const _shoulderAngle = Math.acos(Math.min(Math.max(cosShoulder, -1.0), 1.0));

  const baseRot = new THREE.Quaternion().setFromUnitVectors(
    new THREE.Vector3(0, -1, 0),
    toTarget.normalize()
  );

  return { elbowAngle, shoulderRotation: baseRot };
}
