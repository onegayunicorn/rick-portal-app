/**
 * Client-side Hardened Bridge Client.
 * Signs every native command with HMAC-SHA256 using an ephemeral session key.
 * Falls back to sandbox simulation when the native bridge is not mounted.
 */
export class HardenedBridgeClient {
  private sessionKey: string;

  constructor(sessionKey: string) {
    this.sessionKey = sessionKey;
  }

  async sendCommand(command: string, payload: Record<string, any>): Promise<any> {
    if (!(window as any).SovereignBridge) {
      console.warn("Native bridge not mounted. Operating in browser sandbox mode.");
      return { simulated: true };
    }
    const nonce = crypto.randomUUID();
    const timestamp = Date.now();
    const payloadStr = JSON.stringify(payload);
    const canonical = `${command}:${nonce}:${timestamp}:${payloadStr}`;
    const signature = await this.hmacSha256(canonical, this.sessionKey);

    const envelope = { command, nonce, timestamp, payload, signature };
    const rawResponse = (window as any).SovereignBridge.dispatchSecure(JSON.stringify(envelope));
    const parsed = JSON.parse(rawResponse);
    if (parsed.status !== "SUCCESS") {
      throw new Error(`Native Bridge Error: ${parsed.error}`);
    }
    return parsed.data;
  }

  private async hmacSha256(message: string, key: string): Promise<string> {
    const encoder = new TextEncoder();
    const cryptoKey = await crypto.subtle.importKey(
      "raw",
      encoder.encode(key),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const signatureBuffer = await crypto.subtle.sign("HMAC", cryptoKey, encoder.encode(message));
    return Array.from(new Uint8Array(signatureBuffer))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }
}
