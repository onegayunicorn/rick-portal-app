export interface TimelineCue {
  id: string;
  start: number; // Seconds
  end: number;
  type: "hotspot" | "branch_choice" | "telemetry_ping" | "cv_track";
  coordinates?: { x: number; y: number; width?: number; height?: number }; // Percentage (0-100)
  payload: {
    label?: string;
    dimensionCode?: string;
    seekTarget?: number;
    action?: (video: HTMLVideoElement) => void;
  };
}

/**
 * Frame-accurate video sync engine.
 * Replaces inaccurate 250ms timeupdate polling with hardware v-synced
 * requestVideoFrameCallback triggers (±16.6ms @ 60fps).
 */
export class VideoSyncEngine {
  private video: HTMLVideoElement;
  private overlay: HTMLElement;
  private cues: TimelineCue[] = [];
  private activeCues = new Set<string>();

  constructor(video: HTMLVideoElement, overlay: HTMLElement, cues: TimelineCue[]) {
    this.video = video;
    this.overlay = overlay;
    this.cues = cues;
    this.initLoop();
  }

  private initLoop() {
    const handleFrame = (now: DOMHighResTimeStamp, metadata?: any) => {
      const currentTime = metadata ? metadata.mediaTime : this.video.currentTime;
      this.evaluateTimeline(currentTime);
      if ("requestVideoFrameCallback" in this.video) {
        (this.video as any).requestVideoFrameCallback(handleFrame);
      } else {
        requestAnimationFrame(() => handleFrame(performance.now()));
      }
    };
    if ("requestVideoFrameCallback" in this.video) {
      (this.video as any).requestVideoFrameCallback(handleFrame);
    } else {
      requestAnimationFrame(() => handleFrame(performance.now()));
    }
  }

  private evaluateTimeline(time: number) {
    const matching = this.cues.filter((c) => time >= c.start && time <= c.end);
    const matchingIds = new Set(matching.map((m) => m.id));

    // Clear stale overlays
    this.activeCues.forEach((id) => {
      if (!matchingIds.has(id)) {
        document.getElementById(`cue-${id}`)?.remove();
        this.activeCues.delete(id);
      }
    });

    // Render active hotspots & branching choices
    matching.forEach((cue) => {
      if (!this.activeCues.has(cue.id)) {
        this.renderCueElement(cue);
        this.activeCues.add(cue.id);
      }
    });
  }

  private renderCueElement(cue: TimelineCue) {
    const el = document.createElement("div");
    el.id = `cue-${cue.id}`;
    el.style.position = "absolute";
    el.style.left = `${cue.coordinates?.x || 50}%`;
    el.style.top = `${cue.coordinates?.y || 50}%`;
    el.style.transform = "translate(-50%, -50%)";
    el.style.pointerEvents = "auto";
    el.style.zIndex = "20";

    if (cue.type === "hotspot") {
      el.innerHTML = `
        <button class="hud-hotspot-btn" style="
          background: rgba(0,255,136,0.2);
          border: 1px solid #00ff88;
          color: #00ff88;
          font-family: monospace;
          padding: 6px 12px;
          border-radius: 4px;
          backdrop-filter: blur(4px);
          cursor: pointer;
          box-shadow: 0 0 10px rgba(0,255,136,0.4);
        ">${cue.payload.label || "SCAN PORTAL NODE"}</button>
      `;
      el.onclick = () => cue.payload.action?.(this.video);
    } else if (cue.type === "branch_choice") {
      el.innerHTML = `
        <div class="branch-modal" style="
          background: rgba(1,10,4,0.9);
          border: 1px solid #00e5ff;
          padding: 12px;
          border-radius: 6px;
          min-width: 200px;
        ">
          <p style="color:#00e5ff;font-size:11px;margin-bottom:8px;">DIMENSIONAL BRANCH POINT</p>
          <button class="branch-btn" id="choice-c137" style="display:block;width:100%;margin-bottom:6px;padding:6px;background:#00ff8822;border:1px solid #00ff88;color:#00ff88;cursor:pointer;">Jump to C-137</button>
          <button class="branch-btn" id="choice-reset" style="display:block;width:100%;padding:6px;background:#ff005522;border:1px solid #ff0055;color:#ff0055;cursor:pointer;">Abort Jump</button>
        </div>
      `;
      el.querySelector("#choice-c137")?.addEventListener("click", () => {
        this.video.currentTime = cue.payload.seekTarget || 0;
      });
      el.querySelector("#choice-reset")?.addEventListener("click", () => {
        el.remove();
        this.activeCues.delete(cue.id);
      });
    }
    this.overlay.appendChild(el);
  }

  destroy() {
    this.activeCues.forEach((id) => document.getElementById(`cue-${id}`)?.remove());
    this.activeCues.clear();
  }
}
