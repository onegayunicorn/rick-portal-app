import type { PortalGistPayload } from "./gist-client";

/** Serialization of portal states to Gist JSON */
export function packCoordinate(
  dimension: string,
  resonance: number,
  stability: number,
  logs: Array<{ actor: string; text: string; time: string }>,
  model = "Llama-3.2-1B-Instruct-q4f16_1-MLC",
  temperature = 0.7
): PortalGistPayload {
  return {
    dimension,
    resonance,
    stability,
    orchestratorLogs: logs,
    offlineModelConfig: { model, temperature },
  };
}

export function unpackCoordinate(json: string): PortalGistPayload {
  return JSON.parse(json) as PortalGistPayload;
}

/** Export to local JSON file (offline / air-gapped fallback) */
export function exportToLocalFile(payload: PortalGistPayload): void {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `portal-${payload.dimension.toLowerCase()}-${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
}
