export interface PortalGistPayload {
  dimension: string;
  resonance: number;
  stability: number;
  orchestratorLogs: Array<{ actor: string; text: string; time: string }>;
  offlineModelConfig: {
    model: string;
    temperature: number;
  };
}

export class GistSyncClient {
  private token: string | null;

  constructor(token?: string) {
    this.token = token || process.env.GITHUB_GIST_TOKEN || null;
  }

  async exportPortalState(payload: PortalGistPayload, isPublic = false): Promise<string> {
    const filename = `portal-${payload.dimension.toLowerCase().replace(/[^a-z0-9]/g, "-")}.json`;
    const headers: Record<string, string> = {
      Accept: "application/vnd.github+json",
      "Content-Type": "application/json",
    };
    if (this.token) {
      headers["Authorization"] = `Bearer ${this.token}`;
    }
    const body = {
      description: `Rick C-137 Portal Coordinate & Orchestrator Snapshot: ${payload.dimension}`,
      public: isPublic,
      files: {
        [filename]: { content: JSON.stringify(payload, null, 2) },
      },
    };
    const res = await fetch("https://api.github.com/gists", {
      method: "POST",
      headers,
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      throw new Error(`Failed to create Gist: ${res.statusText}`);
    }
    const data = await res.json();
    return data.html_url; // Direct Gist URL
  }

  async importPortalState(gistId: string): Promise<PortalGistPayload> {
    const res = await fetch(`https://api.github.com/gists/${gistId}`);
    if (!res.ok) throw new Error("Gist not found or unreachable");
    const data = await res.json();
    const firstFile = Object.values(data.files)[0] as { content: string };
    return JSON.parse(firstFile.content) as PortalGistPayload;
  }
}
