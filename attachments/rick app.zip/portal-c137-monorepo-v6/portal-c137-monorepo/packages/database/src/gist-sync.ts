export interface TelemetryExportPayload {
  session_id: string;
  generated_at: string;
  coherence: number;
  events: any[];
}

/**
 * Export telemetry snapshot to GitHub Gist (v6).
 * Uses X-GitHub-Api-Version 2022-11-28 header.
 */
export async function exportTelemetryToGist(
  githubToken: string,
  payload: TelemetryExportPayload,
  isPublic: boolean = false
): Promise<{ gistId: string; url: string }> {
  const content = JSON.stringify(payload, null, 2);
  const response = await fetch("https://api.github.com/gists", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${githubToken}`,
      Accept: "application/vnd.github+json",
      "Content-Type": "application/json",
      "X-GitHub-Api-Version": "2022-11-28",
    },
    body: JSON.stringify({
      description: `Portal C-137 Telemetry Snapshot [${payload.session_id}]`,
      public: isPublic,
      files: { "portal-telemetry.json": { content } },
    }),
  });
  if (!response.ok) {
    throw new Error(`GitHub Gist API error: ${response.statusText}`);
  }
  const data = await response.json();
  return { gistId: data.id, url: data.html_url };
}
