import { drizzle } from "drizzle-orm/libsql";
import { createClient } from "@libsql/client";
import * as schema from "../drizzle/schema";

// Edge / LibSQL / SQLite-WASM Drizzle client for zero-latency local storage
const client = createClient({
  url: process.env.LIBSQL_URL || "file:local-portal.db",
});

export const db = drizzle(client, { schema });
export { schema };
