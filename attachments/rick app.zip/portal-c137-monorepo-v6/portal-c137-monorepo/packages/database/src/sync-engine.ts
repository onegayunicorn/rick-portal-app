import { db, schema } from "./drizzle-client";
import { prisma } from "./prisma-client";
import { eq } from "drizzle-orm";

/**
 * Two-way sync between local Drizzle (SQLite/WASM) and cloud Prisma (PostgreSQL).
 * Runs as a background worker, batching telemetry writes to avoid per-keystroke I/O.
 */
export class SyncEngine {
  private queue: Array<() => Promise<void>> = [];
  private timer: ReturnType<typeof setInterval> | null = null;

  start(intervalMs = 5000) {
    this.timer = setInterval(() => this.flush(), intervalMs);
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
  }

  enqueue(task: () => Promise<void>) {
    this.queue.push(task);
  }

  private async flush() {
    if (this.queue.length === 0) return;
    const batch = this.queue.splice(0, this.queue.length);
    try {
      await Promise.all(batch.map((t) => t()));
      // Mark local records as synced
      await db
        .update(schema.localCoordinates)
        .set({ syncedToCloud: true })
        .where(eq(schema.localCoordinates.syncedToCloud, false));
    } catch (err) {
      console.error("[Portal Sync] Batch push failed, re-queueing:", err);
      this.queue.unshift(...batch);
    }
  }

  /** Push a local coordinate + telemetry batch to cloud Prisma */
  async pushLocalToCloud(dimensionCode: string) {
    const local = await db.query.localCoordinates.findFirst({
      where: eq(schema.localCoordinates.dimensionCode, dimensionCode),
    });
    if (!local) return;
    await prisma.dimensionCoordinate.upsert({
      where: { dimensionCode },
      create: {
        dimensionCode: local.dimensionCode,
        stability: local.stability,
        resonanceHz: local.resonanceHz,
        status: local.status,
        gistUrl: local.gistUrl ?? undefined,
      },
      update: {
        stability: local.stability,
        resonanceHz: local.resonanceHz,
        status: local.status,
      },
    });
  }
}
