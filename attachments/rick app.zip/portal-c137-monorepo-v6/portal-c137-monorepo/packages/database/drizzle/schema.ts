import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";

// Edge & SQLite local schema definitions (zero-latency offline storage)
export const localCoordinates = sqliteTable("local_coordinates", {
  id: text("id").primaryKey(),
  dimensionCode: text("dimension_code").notNull().unique(),
  stability: real("stability").default(1.0).notNull(),
  resonanceHz: integer("resonance_hz").default(1207).notNull(),
  status: text("status").default("ACTIVE").notNull(),
  gistUrl: text("gist_url"),
  syncedToCloud: integer("synced_to_cloud", { mode: "boolean" }).default(false).notNull(),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull(),
});

export const localTelemetryLogs = sqliteTable("local_telemetry_logs", {
  id: text("id").primaryKey(),
  coordinateId: text("coordinate_id").references(() => localCoordinates.id),
  message: text("message").notNull(),
  actor: text("actor").notNull(),
  timestamp: integer("timestamp", { mode: "timestamp" }).notNull(),
});

// v6: telemetry events with quantum coherence metrics
export const telemetryEvents = sqliteTable("telemetry_events", {
  id: text("id").primaryKey(),
  timestamp: integer("timestamp").notNull(),
  quantumCoherence: real("quantum_coherence").notNull(),
  fluxDecay: real("flux_decay").notNull(),
  activeUniverseId: text("active_universe_id").notNull(),
  statusFlag: text("status_flag").notNull(),
});

// v6: interactive video cues persisted locally
export const interactiveCues = sqliteTable("interactive_cues", {
  id: text("id").primaryKey(),
  mediaId: text("media_id").notNull(),
  startTime: real("start_time").notNull(),
  endTime: real("end_time").notNull(),
  cueType: text("cue_type").notNull(),
  payloadJson: text("payload_json").notNull(),
});

// v6: gist sync log with checksum verification
export const syncLogs = sqliteTable("sync_logs", {
  gistId: text("gist_id").primaryKey(),
  lastSyncedAt: integer("last_synced_at").notNull(),
  checksum: text("checksum").notNull(),
});
