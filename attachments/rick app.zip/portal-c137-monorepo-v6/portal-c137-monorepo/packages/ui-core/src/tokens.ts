export const PORTAL_TOKENS = {
  colors: {
    portalGreen: "#00ff88",
    portalYellow: "#d4ff00",
    portalVoid: "#020b05",
    portalDim: "rgba(0,255,136,0.15)",
    hudCyan: "#00e5ff",
    hudAlert: "#ff0055",
    hudBorder: "rgba(0,255,136,0.35)",
  },
  typography: {
    fontMono: '"SF Mono", "Fira Code", "Courier New", monospace',
  },
  dimensions: {
    viewportMaxWidth: 440,
    viewportMaxHeight: 880,
  },
  telemetry: {
    defaultDimension: "C-137",
    defaultResonanceHz: 1207,
    defaultStability: 0.998,
  },
} as const;
