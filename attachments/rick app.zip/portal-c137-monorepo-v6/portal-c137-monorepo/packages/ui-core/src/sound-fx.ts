/** In-browser synthesized portal sound effects (zero external audio files). */
export class PortalSoundFX {
  private ctx: AudioContext | null = null;

  private ensureCtx() {
    if (!this.ctx) {
      const Ctx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new Ctx();
    }
    return this.ctx;
  }

  play(freq = 440, type: OscillatorType = "sawtooth", duration = 0.35) {
    const ctx = this.ensureCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(freq * 2.5, ctx.currentTime + duration * 0.85);
    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  }

  firePortal() { this.play(1207, "sawtooth", 0.5); }
  pinCoordinate() { this.play(880, "sine", 0.25); }
  collapse() { this.play(180, "triangle", 0.6); }
  listen() { this.play(600, "sine", 0.2); }
  dispatch() { this.play(750, "sawtooth", 0.3); }
}
