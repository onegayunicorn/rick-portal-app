/** Shared Tailwind preset - Rick C-137 Portal theme tokens */
export const portalTailwindPreset = {
  theme: {
    extend: {
      colors: {
        portal: {
          green: "#00ff88",
          yellow: "#d4ff00",
          void: "#020b05",
          dim: "rgba(0,255,136,0.15)",
        },
        hud: {
          cyan: "#00e5ff",
          alert: "#ff0055",
          border: "rgba(0,255,136,0.35)",
        },
      },
      fontFamily: {
        mono: ['"SF Mono"', '"Fira Code"', '"Courier New"', "monospace"],
      },
      boxShadow: {
        "portal-glow": "0 0 40px rgba(0,255,136,0.2)",
        "portal-card": "0 0 25px rgba(0,255,136,0.15)",
      },
      animation: {
        "pulse-slow": "pulse 2s infinite",
      },
    },
  },
  plugins: [],
};

export default portalTailwindPreset;
