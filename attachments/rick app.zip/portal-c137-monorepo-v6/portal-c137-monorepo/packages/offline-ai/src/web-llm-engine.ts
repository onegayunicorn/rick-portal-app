import * as webllm from "@mlc-ai/web-llm";

/**
 * Sovereign Local AI Engine.
 * Runs Llama-3.2-1B-Instruct quantized q4f16 entirely in-browser via WebGPU.
 * Zero external API dependency - works fully offline after first model download.
 */
export class SovereignAIEngine {
  private engine: webllm.MLCEngine | null = null;
  private selectedModel = "Llama-3.2-1B-Instruct-q4f16_1-MLC";

  async init(onProgress?: (report: webllm.InitProgressReport) => void): Promise<void> {
    if (!navigator.gpu) {
      throw new Error("WebGPU is required for Sovereign Local AI. Enable hardware acceleration.");
    }
    const appConfig: webllm.AppConfig = {
      model_list: [
        {
          model_url: "/models/Llama-3.2-1B-Instruct-q4f16_1-MLC/",
          model_id: "Llama-3.2-1B-Instruct-q4f16_1-MLC",
          model_lib_url: "/models/Llama-3.2-1B-Instruct-q4f16_1-ctx4k_webgpu.wasm",
          required_features: ["shader-f16"],
        },
      ],
    };
    this.engine = await webllm.CreateMLCEngine(this.selectedModel, {
      appConfig,
      initProgressCallback: onProgress,
    });
  }

  async generateStream(
    prompt: string,
    systemPrompt: string,
    onChunk: (text: string) => void
  ): Promise<string> {
    if (!this.engine) throw new Error("AI Engine not initialized");
    const messages: webllm.ChatCompletionMessageParam[] = [
      {
        role: "system",
        content:
          systemPrompt ||
          "You are Rick C-137's Portal Orchestrator AI. Speak concisely, cynically, and scientifically.",
      },
      { role: "user", content: prompt },
    ];
    const asyncChunkGenerator = await this.engine.chat.completions.create({
      messages,
      stream: true,
      temperature: 0.7,
      max_tokens: 512,
    });
    let fullResponse = "";
    for await (const chunk of asyncChunkGenerator) {
      const delta = chunk.choices[0]?.delta?.content || "";
      fullResponse += delta;
      onChunk(fullResponse);
    }
    return fullResponse;
  }

  async dispose(): Promise<void> {
    await this.engine?.unload?.();
    this.engine = null;
  }

  get isReady(): boolean {
    return this.engine !== null;
  }
}
