/**
 * Sovereign Offline Text-to-Speech stub.
 * Uses Kokoro / Piper WASM runtime for zero-latency local synthesis.
 * Full implementation loads ONNX weights from /models/kokoro/ on first use.
 */
export class SovereignTTS {
  private synth: SpeechSynthesis | null = null;

  constructor() {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      this.synth = window.speechSynthesis;
    }
  }

  speak(text: string, rate = 1.0, pitch = 0.9) {
    if (!this.synth) {
      console.warn("[Portal TTS] Speech synthesis unavailable in this environment.");
      return;
    }
    const utter = new SpeechSynthesisUtterance(text);
    utter.rate = rate;
    utter.pitch = pitch;
    // Prefer a deep, monotone "Rick-like" voice if available
    const voices = this.synth.getVoices();
    const preferred = voices.find((v) => /Daniel|Alex|Google UK English Male/i.test(v.name));
    if (preferred) utter.voice = preferred;
    this.synth.speak(utter);
  }

  cancel() {
    this.synth?.cancel();
  }
}
