import { pipeline, env } from "@xenova/transformers";

// Force local assets, disable remote HuggingFace CDN fallbacks
env.allowRemoteModels = false;
env.localModelPath = "/models/";

/**
 * Sovereign Offline Speech-to-Text.
 * Whisper-tiny quantized INT8 running on WebGPU via ONNX Runtime Web.
 */
export class SovereignWhisper {
  private transcriber: any = null;

  async init() {
    this.transcriber = await pipeline("automatic-speech-recognition", "whisper-tiny-en", {
      quantized: true,
      device: "webgpu",
    });
  }

  async transcribeAudioBlob(audioBlob: Blob): Promise<string> {
    if (!this.transcriber) throw new Error("Whisper STT not initialized");
    const arrayBuffer = await audioBlob.arrayBuffer();
    const audioContext = new AudioContext({ sampleRate: 16000 });
    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
    const audioData = audioBuffer.getChannelData(0);
    const output = await this.transcriber(audioData);
    return output.text.trim();
  }
}
