# Standalone Single-File HTML Build

Zero-build-step sovereign web distribution. No npm, Vite, or Webpack required.

## Run

```bash
open index.html          # macOS
xdg-open index.html      # Linux
start index.html         # Windows
# Or: python3 -m http.server 8000
```

## Deploy

- Cloudflare Pages: `pnpm dlx wrangler pages deploy . --project-name rick-portal-ui`
- GitHub Pages: Automated via `.github/workflows/deploy-html.yml`
- Docker Nginx: `docker build -t rick-portal-html . && docker run -d -p 8080:80 rick-portal-html`

## Features

- Embedded WebGL portal vortex shader (compiled in-browser)
- WebAudio synthesized portal sound FX + real-time frequency visualizer
- Holographic HUD with scanlines, chromatic vignette, typewriter terminal
- Web Speech API voice input with graceful fallback
- Local JSON snapshot export (offline Gist fallback)
- 100% self-contained — zero remote CDNs, zero external dependencies
