package dev.sovereign.portal

import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Sovereign Native Android Shell with Hardened Zero-Trust IPC Bridge.
 * Serves PWA bundle via WebViewAssetLoader under a secure origin.
 * All native commands require HMAC-SHA256 signature + nonce anti-replay.
 */
class MainActivity : AppCompatActivity() {

    private val sharedSecretKey = "SOVEREIGN_SUPER_SECRET_HMAC_KEY_2026"
    private val processedNonces = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = false
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: android.webkit.WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
        }

        webView.addJavascriptInterface(object {
            @JavascriptInterface
            fun executeCommand(envelopeJson: String): String {
                return try {
                    val json = JSONObject(envelopeJson)
                    val command = json.getString("command")
                    val payload = json.getJSONObject("payload").toString()
                    val timestamp = json.getLong("timestamp")
                    val nonce = json.getString("nonce")
                    val signature = json.getString("signature")

                    val now = System.currentTimeMillis()
                    if (Math.abs(now - timestamp) > 5000) {
                        return "{\"error\":\"REPLAY_EXPIRED\",\"status\":403}"
                    }
                    if (processedNonces.contains(nonce)) {
                        return "{\"error\":\"REPLAY_NONCE_DUPLICATE\",\"status\":403}"
                    }
                    processedNonces.add(nonce)

                    val rawPayload = "$command:$payload:$timestamp:$nonce"
                    val expectedSig = hmacSha256(rawPayload, sharedSecretKey)
                    if (!expectedSig.equals(signature, ignoreCase = true)) {
                        return "{\"error\":\"INVALID_SIGNATURE\",\"status\":401}"
                    }

                    when (command) {
                        "DEVICE_HAPTIC" -> "{\"status\":\"success\",\"result\":\"HAPTIC_TRIGGERED\"}"
                        "STORAGE_WRITE_SECURE" -> "{\"status\":\"success\",\"result\":\"WRITTEN\"}"
                        else -> "{\"error\":\"UNKNOWN_COMMAND\",\"status\":404}"
                    }
                } catch (e: Exception) {
                    "{\"error\":\"${e.message}\",\"status\":500}"
                }
            }
        }, "SovereignAndroidBridge")

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun hmacSha256(data: String, key: String): String {
        val sha256Hmac = Mac.getInstance("HmacSHA256")
        val secretKeySpec = SecretKeySpec(key.toByteArray(Charsets.UTF_8), "HmacSHA256")
        sha256Hmac.init(secretKeySpec)
        val hash = sha256Hmac.doFinal(data.toByteArray(Charsets.UTF_8))
        return hash.joinToString("") { "%02x".format(it) }
    }
}
