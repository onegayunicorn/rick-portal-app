# Native Android Web Assets

Place the built PWA bundle (apps/web/dist/*) into this assets/ directory.
Served via WebViewAssetLoader at https://appassets.androidplatform.net/assets/
with zero CORS / mixed-content issues.
