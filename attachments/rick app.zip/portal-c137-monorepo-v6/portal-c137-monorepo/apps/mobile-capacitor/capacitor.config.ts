import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.rickc137.portal",
  appName: "Portal C-137",
  webDir: "../web/dist",
  backgroundColor: "#010804",
  android: {
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
  ios: {
    contentInset: "always",
    limitsNavigationsToAppBoundDomains: true,
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      backgroundColor: "#010804",
      showSpinner: false,
    },
  },
  server: {
    androidScheme: "https",
  },
};

export default config;
