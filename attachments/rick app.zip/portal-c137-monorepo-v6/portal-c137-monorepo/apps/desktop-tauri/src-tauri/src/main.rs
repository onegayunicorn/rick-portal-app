// Prevents additional console window on Windows in release
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use tauri::Manager;

#[tauri::command]
fn trigger_haptic(intensity: f64) -> Result<String, String> {
    // Desktop haptic simulation via system beep / notification
    println!("[Portal] Haptic trigger intensity: {}", intensity);
    Ok(format!("HAPTIC_FIRED:{}", intensity))
}

#[tauri::command]
fn read_battery_telemetry() -> Result<serde_json::Value, String> {
    Ok(serde_json::json!({
        "voltage_mv": 4120,
        "temperature_c": 28.4,
        "mesh_status": "ACTIVE",
        "dimension": "C-137"
    }))
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![trigger_haptic, read_battery_telemetry])
        .setup(|app| {
            let window = app.get_webview_window("main").unwrap();
            println!("[Portal C-137] Sovereign Desktop Orchestrator initialized.");
            let _ = window.show();
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
