import { portalTailwindPreset } from "@portal/ui-core";

export default {
  presets: [portalTailwindPreset],
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
};
