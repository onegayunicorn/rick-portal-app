# PWA Icons

Place `icon-192.png` and `icon-512.png` (maskable) here.
Generate from the portal-green swirl logo at 1024x1024 with a 20% safe-zone padding.
