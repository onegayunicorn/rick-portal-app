# Video Media

Place transcoded portal video streams here:
- portal-stream.mp4 (9:16, CFR 30fps, closed GOP, +faststart)

Transcode with:
ffmpeg -i source.mp4 -c:v libx264 -r 30 -g 30 -keyint_min 30 -sc_threshold 0 -movflags +faststart -c:a aac portal-stream.mp4
