# Offline AI Models & 3D Assets

Download quantized weights and 3D GLB assets into this directory:

- `Llama-3.2-1B-Instruct-q4f16_1-MLC/` — WebLLM local inference weights (~700MB)
- `whisper-tiny-en/` — Xenova Transformers local STT (~40MB)
- `rick_portal_gun.glb` — DRACO/Meshopt compressed 3D portal gun model (<2MB)

Run `pnpm run download:models` from the monorepo root to fetch all assets.
