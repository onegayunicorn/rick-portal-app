export interface SemanticCue {
  timestamp_ms: number;
  type: "gesture" | "emotion" | "look_at" | "viseme";
  value: string;
  intensity?: number;
  uiTargetPercent?: { x: number; y: number };
}

export interface StructuredAIResponse {
  speech_text: string;
  audio_url?: string;
  visemes: Array<{ time: number; target: string; weight: number }>;
  cues: SemanticCue[];
}

/**
 * Structured AI Output Schema with Kinetic Cue Tags.
 * The LLM orchestration layer returns JSON envelopes carrying synchronized
 * gestural and acoustic metadata.
 */
export interface SovereignAIResponseEnvelope {
  transcript: string;
  audio_url: string;
  duration_ms: number;
  visemes: Array<{
    timestamp_ms: number;
    phoneme: string;
    blendshapes: { [name: string]: number };
  }>;
  gestural_cues: Array<{
    timestamp_ms: number;
    duration_ms: number;
    gesture_type: "POINT_AT_DOM" | "WAVE" | "EMPHASIZE" | "RELOAD_PORTAL";
    target_selector?: string; // e.g. "#resonance-val"
    emotion: "NEUTRAL" | "CONFIDENT" | "ALERT" | "AMUSED";
    hand_pose: "POINT" | "PALM_UP" | "FIST" | "RELAXED";
  }>;
}

/**
 * AI Answer-to-Gesture & Visual Interface Mapping Matrix.
 * Maps semantic conversation states to avatar physiological/kinematic responses.
 */
export const GESTURE_MAPPING_MATRIX = {
  GREETING: {
    viseme: "viseme_aa",
    blendshapes: { happy: 0.6, browInnerUp: 0.4 },
    gaze: { x: 0, y: 0, z: 1.5 },
    leftHand: "RELAXED",
    rightHand: "WAVE",
    hudState: "ORCHESTRATOR_ONLINE_PULSE",
  },
  EXPLAINING_TELEMETRY: {
    viseme: "viseme_DD",
    blendshapes: { neutral: 0.8, eyeSquint: 0.2 },
    gaze: "TELEMETRY_CARD",
    leftHand: "REST_HIP",
    rightHand: "POINT_INDEX_IK",
    hudState: "HIGHLIGHT_RESONANCE_1207",
  },
  DIMENSION_ALERT: {
    viseme: "viseme_PP",
    blendshapes: { angry: 0.4, browDown: 0.7 },
    gaze: "RETICLE_COORDINATE",
    leftHand: "FIST_TENSION_0.8",
    rightHand: "PALM_SWEEP_COLLAPSE",
    hudState: "STABILITY_FLASH_RED_FF0055",
  },
  DELIBERATING: {
    viseme: "viseme_sil",
    blendshapes: { browInnerUp: 0.6, mouthShrug: 0.3 },
    gaze: { x: 0.2, y: 0.8, z: 1.0 },
    leftHand: "OPEN_PALM_CHEST",
    rightHand: "INDEX_TEMPLE",
    hudState: "AUDIO_VIZ_PROCESSING_PULSE",
  },
  PRESENTING_CHOICE: {
    viseme: "viseme_O",
    blendshapes: { smile: 0.5, eyesWide: 0.3 },
    gaze: "BRANCH_MODAL",
    leftHand: "PALMS_UP_OPTION_A",
    rightHand: "PALMS_UP_OPTION_B",
    hudState: "RENDER_BRANCH_BUTTONS",
  },
  PORTAL_DISCHARGE: {
    viseme: "viseme_SS",
    blendshapes: { intenseFocus: 0.9 },
    gaze: { x: 0, y: 0, z: -2.0 },
    leftHand: "SUPPORT_BARREL",
    rightHand: "GRIP_TRIGGER",
    hudState: "ACCRETION_DISK_EXPAND_300",
  },
} as const;

/**
 * Parses AI output markup (<gesture .../>, <emotion .../> tags) into
 * structured visemes + semantic cues.
 */
export function parseAIOutputMarkup(rawText: string): StructuredAIResponse {
  const cues: SemanticCue[] = [];
  const tagRegex = /<([a-z_]+)\s+([^>]+)\/>/gi;
  let match: RegExpExecArray | null;
  while ((match = tagRegex.exec(rawText)) !== null) {
    const tagName = match[1];
    const attrString = match[2];
    const attrs: Record<string, string> = {};
    attrString.replace(/([a-zA-Z0-9_]+)="([^"]*)"/g, (_, k, v) => {
      attrs[k] = v;
      return "";
    });
    if (tagName === "gesture") {
      cues.push({
        timestamp_ms: parseInt(attrs.time || "0", 10),
        type: "gesture",
        value: attrs.name || "point_right",
        uiTargetPercent:
          attrs.targetX && attrs.targetY
            ? { x: parseFloat(attrs.targetX), y: parseFloat(attrs.targetY) }
            : undefined,
      });
    } else if (tagName === "emotion") {
      cues.push({
        timestamp_ms: parseInt(attrs.time || "0", 10),
        type: "emotion",
        value: attrs.name || "neutral",
        intensity: parseFloat(attrs.intensity || "1.0"),
      });
    }
  }
  const cleanSpeech = rawText.replace(tagRegex, "").trim();
  const syntheticVisemes = generateVisemesFromText(cleanSpeech);
  return { speech_text: cleanSpeech, visemes: syntheticVisemes, cues };
}

/** Generate synthetic viseme timeline from text (fallback when no TTS phoneme data). */
function generateVisemesFromText(
  text: string
): Array<{ time: number; target: string; weight: number }> {
  const visemes: Array<{ time: number; target: string; weight: number }> = [];
  const chars = text.toLowerCase().split("");
  let timeCursor = 0.0;
  chars.forEach((char) => {
    let target = "viseme_sil";
    let duration = 0.08;
    if ("aei".includes(char)) { target = "viseme_aa"; duration = 0.12; }
    else if ("ou".includes(char)) { target = "viseme_O"; duration = 0.12; }
    else if ("bmp".includes(char)) { target = "viseme_PP"; duration = 0.08; }
    else if ("fv".includes(char)) { target = "viseme_FF"; duration = 0.08; }
    else if ("th".includes(char)) { target = "viseme_TH"; duration = 0.09; }
    visemes.push({ time: timeCursor, target, weight: 0.9 });
    visemes.push({ time: timeCursor + duration, target: "viseme_sil", weight: 0.1 });
    timeCursor += duration;
  });
  return visemes;
}
