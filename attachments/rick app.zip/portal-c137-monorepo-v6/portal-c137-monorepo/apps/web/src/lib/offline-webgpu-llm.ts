import { pipeline, env } from "@huggingface/transformers";

env.allowLocalModels = true;
env.useBrowserCache = true;

/**
 * Sovereign Offline AI Engine (WebGPU LLM).
 * In-browser, fully zero-network AI reasoning via WebGPU accelerated quantization.
 * Uses Qwen2.5-0.5B-Instruct quantized q4 ONNX weights.
 */
export class SovereignAIEngine {
  private generator: any = null;
  private isInitialized: boolean = false;

  async initialize(onProgress?: (progress: number, status: string) => void): Promise<void> {
    if (this.isInitialized) return;
    if (onProgress) onProgress(0.1, "Verifying WebGPU hardware acceleration...");
    if (!("gpu" in navigator)) {
      throw new Error("WebGPU hardware accelerator not supported on this platform.");
    }
    if (onProgress) onProgress(0.4, "Loading quantized model weights into GPU VRAM...");
    this.generator = await pipeline("text-generation", "onnx-community/Qwen2.5-0.5B-Instruct", {
      device: "webgpu",
      dtype: "q4",
      progress_callback: (info: any) => {
        if (onProgress && info.status === "progress") {
          onProgress(info.progress, `Downloading weights: ${info.file}`);
        }
      },
    });
    this.isInitialized = true;
    if (onProgress) onProgress(1.0, "Sovereign Offline AI Core Ready");
  }

  async generateResponse(prompt: string, onToken?: (token: string) => void): Promise<string> {
    if (!this.generator) await this.initialize();
    const messages = [
      {
        role: "system",
        content:
          'You are the Rick C-137 Sovereign Interface AI. You output responses embedded with gesture tags, e.g. <gesture name="point_ui" targetX="75" targetY="40" /> and <emotion name="smug" intensity="0.8" />.',
      },
      { role: "user", content: prompt },
    ];
    const output = await this.generator(messages, {
      max_new_tokens: 256,
      temperature: 0.7,
      top_p: 0.95,
      callback_function: (beams: any[]) => {
        if (onToken && beams[0]?.generated_text) {
          onToken(beams[0].generated_text);
        }
      },
    });
    const parts = output[0].generated_text;
    return parts[parts.length - 1].content;
  }

  get ready(): boolean {
    return this.isInitialized;
  }
}

export const sovereignAI = new SovereignAIEngine();
