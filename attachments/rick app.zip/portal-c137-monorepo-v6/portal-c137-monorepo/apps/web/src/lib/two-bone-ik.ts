import * as THREE from "three";

export interface TwoBoneIKChain {
  root: THREE.Bone;   // Shoulder
  mid: THREE.Bone;    // Elbow
  effector: THREE.Bone; // Wrist
  lengthA: number;    // Upper arm length
  lengthB: number;    // Forearm length
}

/**
 * Solves analytic Two-Bone IK in 3D using the Law of Cosines.
 * Positions humanoid arms pointing precisely at UI target points in 3D world space.
 */
export function solveTwoBoneIK(
  chain: TwoBoneIKChain,
  targetWorldPos: THREE.Vector3,
  _poleTarget: THREE.Vector3
): { elbowAngle: number; shoulderRotation: THREE.Quaternion } {
  const rootWorldPos = new THREE.Vector3();
  chain.root.getWorldPosition(rootWorldPos);
  const a = chain.lengthA;
  const b = chain.lengthB;
  const dir = new THREE.Vector3().subVectors(targetWorldPos, rootWorldPos);
  const targetDist = Math.min(dir.length(), a + b - 0.001);

  // Law of Cosines for elbow angle
  const cosElbow = (a * a + b * b - targetDist * targetDist) / (2 * a * b);
  const elbowAngle = Math.PI - Math.acos(Math.max(-1, Math.min(1, cosElbow)));

  const cosShoulder = (a * a + targetDist * targetDist - b * b) / (2 * a * targetDist);
  const shoulderOffsetAngle = Math.acos(Math.max(-1, Math.min(1, cosShoulder)));

  dir.normalize();
  const shoulderRotation = new THREE.Quaternion().setFromUnitVectors(
    new THREE.Vector3(0, -1, 0),
    dir
  );

  // Apply to bones if they have parents in a real rig
  const parent = chain.root.parent;
  if (parent) {
    chain.root.lookAt(targetWorldPos);
    chain.root.rotateY(shoulderOffsetAngle);
    chain.mid.rotation.set(0, 0, 0);
    chain.mid.rotateZ(elbowAngle);
  }

  return { elbowAngle, shoulderRotation };
}

/**
 * Projects a 2D screen coordinate (percentage 0-100) into 3D world space.
 * Used for screen-to-world coordinate projection for precise IK pointing.
 */
export function projectScreenToWorld(
  screenXPercent: number,
  screenYPercent: number,
  camera: THREE.Camera,
  targetZPlane: number = 0.5
): THREE.Vector3 {
  const ndcX = (screenXPercent / 100) * 2 - 1;
  const ndcY = -(screenYPercent / 100) * 2 + 1;
  const vector = new THREE.Vector3(ndcX, ndcY, 0.5);
  vector.unproject(camera);
  const dir = vector.sub(camera.position).normalize();
  const distance = (targetZPlane - camera.position.z) / dir.z;
  return camera.position.clone().add(dir.multiplyScalar(distance));
}
