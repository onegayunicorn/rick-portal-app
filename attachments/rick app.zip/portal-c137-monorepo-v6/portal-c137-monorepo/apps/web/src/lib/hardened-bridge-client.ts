export interface BridgeMessage<T = any> {
  command: string;
  payload: T;
  timestamp: number;
  nonce: string;
  signature: string;
}

/**
 * Hardened Native IPC Bridge Client (Security & Hardware).
 * Zero-trust HMAC-SHA256 authenticated IPC bridge for native hardware execution.
 * Supports both Android (SovereignAndroidBridge) and Tauri (__TAURI_INVOKE__) runtimes.
 */
export class HardenedBridgeClient {
  private secretKey: string;

  constructor(sharedSecretKey: string) {
    this.secretKey = sharedSecretKey;
  }

  private async signData(message: string): Promise<string> {
    const enc = new TextEncoder();
    const key = await crypto.subtle.importKey(
      "raw",
      enc.encode(this.secretKey),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const signature = await crypto.subtle.sign("HMAC", key, enc.encode(message));
    return Array.from(new Uint8Array(signature))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }

  async invokeNative<TReq, TRes>(command: string, payload: TReq): Promise<TRes> {
    const timestamp = Date.now();
    const nonce = crypto.randomUUID();
    const payloadStr = JSON.stringify(payload);
    const rawSigningPayload = `${command}:${payloadStr}:${timestamp}:${nonce}`;
    const signature = await this.signData(rawSigningPayload);

    const bridgeEnvelope: BridgeMessage<TReq> = {
      command,
      payload,
      timestamp,
      nonce,
      signature,
    };

    if (typeof (window as any).SovereignAndroidBridge !== "undefined") {
      const resRaw = (window as any).SovereignAndroidBridge.executeCommand(
        JSON.stringify(bridgeEnvelope)
      );
      return JSON.parse(resRaw) as TRes;
    } else if (typeof (window as any).__TAURI_INVOKE__ !== "undefined") {
      return (window as any).__TAURI_INVOKE__("sovereign_bridge", bridgeEnvelope);
    } else {
      console.warn("[HardenedBridge] Native bridge absent. Running browser emulation mode.");
      return { status: "mocked_ok", data: payload } as any;
    }
  }
}
