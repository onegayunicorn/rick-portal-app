import React, { useEffect, useRef, useState } from "react";

export interface TimelineCue {
  id: string;
  start: number;
  end: number;
  type: "hotspot" | "branch_choice" | "telemetry_trigger";
  x?: number; // percentage (0-100)
  y?: number; // percentage (0-100)
  title?: string;
  payload?: any;
  action?: () => void;
  choices?: Array<{ label: string; seekTo: number }>;
}

interface InteractiveVideoStageProps {
  src: string;
  timelineCues: TimelineCue[];
  onCueTrigger?: (cue: TimelineCue) => void;
}

/**
 * Layered Interactive Video & Hotspot Engine.
 * Layer 1: native HTML5 <video>
 * Layer 2: transparent 2D canvas overlay (pulsing reticles)
 * Layer 3: interactive DOM UI overlay (hotspot buttons, branch choices)
 * Synchronized via requestVideoFrameCallback for sub-frame accuracy.
 */
export const InteractiveVideoStage: React.FC<InteractiveVideoStageProps> = ({
  src,
  timelineCues,
  onCueTrigger,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [activeCues, setActiveCues] = useState<TimelineCue[]>([]);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    let isSubscribed = true;
    let callbackHandle: number | null = null;

    const onFrame = (now: DOMHighResTimeStamp, metadata: any) => {
      if (!isSubscribed) return;
      const mediaTime = metadata?.mediaTime || video.currentTime;
      setCurrentTime(mediaTime);
      const matches = timelineCues.filter(
        (cue) => mediaTime >= cue.start && mediaTime <= cue.end
      );
      setActiveCues(matches);
      matches.forEach((cue) => {
        if (cue.type === "telemetry_trigger" && onCueTrigger) onCueTrigger(cue);
      });
      renderCanvasOverlay(mediaTime, matches);
      if ("requestVideoFrameCallback" in video) {
        callbackHandle = (video as any).requestVideoFrameCallback(onFrame);
      } else {
        callbackHandle = requestAnimationFrame((ts) =>
          onFrame(ts, { mediaTime: video.currentTime })
        );
      }
    };

    if ("requestVideoFrameCallback" in video) {
      callbackHandle = (video as any).requestVideoFrameCallback(onFrame);
    } else {
      callbackHandle = requestAnimationFrame((ts) =>
        onFrame(ts, { mediaTime: video.currentTime })
      );
    }

    return () => {
      isSubscribed = false;
      if (callbackHandle !== null) {
        if ("cancelVideoFrameCallback" in (videoRef.current || {})) {
          (videoRef.current as any).cancelVideoFrameCallback(callbackHandle);
        } else {
          cancelAnimationFrame(callbackHandle);
        }
      }
    };
  }, [timelineCues, onCueTrigger]);

  const renderCanvasOverlay = (time: number, cues: TimelineCue[]) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    cues.forEach((cue) => {
      if (cue.type === "hotspot" && cue.x !== undefined && cue.y !== undefined) {
        const px = (cue.x / 100) * canvas.width;
        const py = (cue.y / 100) * canvas.height;
        const pulse = 10 + Math.sin(time * 6) * 4;
        ctx.save();
        ctx.strokeStyle = "#00ff88";
        ctx.lineWidth = 2;
        ctx.shadowColor = "#00ff88";
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.arc(px, py, pulse + 12, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(px, py, 4, 0, Math.PI * 2);
        ctx.fillStyle = "#00ff88";
        ctx.fill();
        ctx.restore();
      }
    });
  };

  const handleBranchSelect = (targetTime: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = targetTime;
      videoRef.current.play();
    }
  };

  const cycleSpeed = () => {
    const next = playbackSpeed === 1.0 ? 0.5 : playbackSpeed === 0.5 ? 2.0 : 1.0;
    setPlaybackSpeed(next);
    if (videoRef.current) videoRef.current.playbackRate = next;
  };

  return (
    <div className="relative w-full aspect-video rounded-xl overflow-hidden border border-emerald-500/40 bg-black shadow-[0_0_30px_rgba(0,255,136,0.15)]">
      {/* Layer 1: Native HTML5 Video Engine */}
      <video
        ref={videoRef}
        src={src}
        className="w-full h-full object-cover select-none"
        playsInline
        autoPlay
        muted
        loop
        crossOrigin="anonymous"
      />
      {/* Layer 2: Transparent 2D Canvas Overlay */}
      <canvas
        ref={canvasRef}
        width={1920}
        height={1080}
        className="absolute inset-0 w-full h-full pointer-events-none z-10"
      />
      {/* Layer 3: Interactive DOM UI Overlay */}
      <div className="absolute inset-0 pointer-events-none z-20">
        {activeCues.map((cue) => {
          if (cue.type === "hotspot" && cue.x !== undefined && cue.y !== undefined) {
            return (
              <button
                key={cue.id}
                onClick={() => (cue.action ? cue.action() : alert(`Activated: ${cue.title}`))}
                style={{ left: `${cue.x}%`, top: `${cue.y}%` }}
                className="absolute pointer-events-auto -translate-x-1/2 -translate-y-1/2 px-3 py-1.5 rounded-md bg-black/80 border border-emerald-400 text-emerald-300 font-mono text-xs shadow-lg hover:scale-110 active:scale-95 transition-all flex items-center gap-2"
              >
                {cue.title || "Examine Object"}
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              </button>
            );
          }
          if (cue.type === "branch_choice" && cue.choices) {
            return (
              <div
                key={cue.id}
                className="absolute inset-x-0 bottom-12 pointer-events-auto flex justify-center items-center gap-4 bg-black/70 backdrop-blur-md p-4 border-t border-emerald-500/30"
              >
                <span className="text-emerald-400 font-mono text-sm tracking-wider uppercase font-bold">
                  Dimensional Choice Point:
                </span>
                {cue.choices.map((choice, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleBranchSelect(choice.seekTo)}
                    className="px-4 py-2 rounded bg-emerald-950/80 border border-emerald-400 text-emerald-200 hover:bg-emerald-500 hover:text-black font-mono text-xs font-semibold uppercase tracking-wider transition-all"
                  >
                    {choice.label} ({choice.seekTo}s)
                  </button>
                ))}
              </div>
            );
          }
          return null;
        })}
      </div>
      {/* Playback telemetry chip */}
      <div className="absolute top-3 right-3 z-30 pointer-events-auto flex items-center gap-2 bg-black/70 border border-emerald-500/30 px-3 py-1 rounded text-emerald-400 font-mono text-[11px]">
        <span>T: {currentTime.toFixed(2)}s</span>
        <span>·</span>
        <button onClick={cycleSpeed} className="hover:underline">
          {playbackSpeed}x
        </button>
      </div>
    </div>
  );
};
