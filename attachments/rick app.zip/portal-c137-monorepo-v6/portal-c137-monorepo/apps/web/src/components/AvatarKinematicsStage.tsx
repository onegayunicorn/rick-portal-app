import React, { useRef, useEffect } from "react";
import * as THREE from "three";
import { solveTwoBoneIK, projectScreenToWorld } from "../lib/two-bone-ik";
import { VisemeBlender } from "@portal/graphics-engine";

interface AvatarKinematicsStageProps {
  vrmUrl?: string;
  activeGesture?: {
    gesture_type: string;
    target_selector?: string;
    hand_pose?: string;
  } | null;
}

/**
 * 3D Avatar Kinematics Stage.
 * Loads a VRM avatar, applies two-bone IK arm pointing at HUD targets,
 * and drives viseme lip-sync blendshapes from AI audio cues.
 */
export const AvatarKinematicsStage: React.FC<AvatarKinematicsStageProps> = ({
  vrmUrl = "/models/avatar.vrm",
  activeGesture,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const gestureRef = useRef(activeGesture);
  gestureRef.current = activeGesture;

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
    camera.position.set(0, 1.4, 2.2);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    mount.appendChild(renderer.domElement);

    // Lighting
    const key = new THREE.DirectionalLight(0x00ff88, 1.2);
    key.position.set(2, 3, 2);
    scene.add(key);
    scene.add(new THREE.AmbientLight(0x224433, 0.6));

    // Placeholder avatar rig (VRM loader would replace this in production)
    const avatar = new THREE.Group();
    const body = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.25, 0.8, 4, 16),
      new THREE.MeshStandardMaterial({ color: 0x1a3a2a, emissive: 0x003311, metalness: 0.6, roughness: 0.3 })
    );
    body.position.y = 1.0;
    avatar.add(body);
    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.18, 32, 32),
      new THREE.MeshStandardMaterial({ color: 0x2a5a3a, emissive: 0x004422 })
    );
    head.position.y = 1.65;
    avatar.add(head);
    scene.add(avatar);

    const visemeBlender = new VisemeBlender();
    let raf = 0;
    const clock = new THREE.Clock();

    const animate = () => {
      raf = requestAnimationFrame(animate);
      const t = clock.getElapsedTime();
      const delta = clock.getDelta();

      // Procedural idle breathing
      avatar.position.y = Math.sin(t * 1.5) * 0.02;
      avatar.rotation.y = Math.sin(t * 0.5) * 0.1;

      // Apply IK pointing if a gesture target is active
      const g = gestureRef.current;
      if (g?.target_selector) {
        const el = document.querySelector(g.target_selector) as HTMLElement | null;
        if (el) {
          const rect = el.getBoundingClientRect();
          const worldTarget = projectScreenToWorld(
            (rect.left + rect.width / 2) / window.innerWidth * 100,
            (rect.top + rect.height / 2) / window.innerHeight * 100,
            camera,
            0.5
          );
          // Right arm IK chain (simplified - shoulder at (0.3,1.4,0))
          const shoulder = new THREE.Vector3(0.3, 1.4, 0);
          const { elbowAngle } = solveTwoBoneIK(
            { root: { position: shoulder } as any, mid: {} as any, effector: {} as any, lengthA: 0.3, lengthB: 0.3 },
            worldTarget,
            new THREE.Vector3(0, 1, 0)
          );
          head.lookAt(worldTarget);
        }
      }

      // Viseme lip-sync update (drives head scale as proxy for blendshapes)
      visemeBlender.update({ viseme_aa: 0.3 + Math.sin(t * 8) * 0.2 }, delta, null);

      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      if (!mount) return;
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      mount.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, [vrmUrl]);

  return <div ref={mountRef} className="w-full h-full" />;
};
