import React, { useState, useEffect } from "react";

interface Props {
  resonance: number;
  aiReady: boolean;
}

export function TelemetryHeader({ resonance, aiReady }: Props) {
  const [time, setTime] = useState("00:00:00");
  const [battery, setBattery] = useState(100);

  useEffect(() => {
    const tick = () => setTime(new Date().toTimeString().split(" ")[0]);
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if ((navigator as any).getBattery) {
      (navigator as any).getBattery().then((b: any) => {
        const update = () => setBattery(Math.round(b.level * 100));
        update();
        b.addEventListener("levelchange", update);
      });
    }
  }, []);

  return (
    <div className="flex flex-col gap-1.5 border-b pb-2.5" style={{ borderColor: "var(--hud-border)" }}>
      <div className="flex justify-between text-[11px] tracking-wider" style={{ color: "var(--hud-cyan)" }}>
        <span>MESH: SYNCED</span>
        <span>{time}</span>
        <span>PWR: {battery}%</span>
      </div>
      <div className="flex justify-between items-center">
        <h1 className="text-sm font-extrabold tracking-widest uppercase" style={{ textShadow: "0 0 8px var(--portal-green)" }}>
          Rick C-137 Portal
        </h1>
        <span
          className="text-[10px] px-2 py-0.5 rounded font-bold"
          style={{
            background: "var(--portal-dim)",
            border: "1px solid var(--portal-green)",
            color: "var(--portal-green)",
            animation: "pulse 2s infinite",
          }}
        >
          {aiReady ? "ORCHESTRATOR ONLINE" : "ORCHESTRATOR INIT..."}
        </span>
      </div>
      <div className="flex justify-between text-[11px]" style={{ color: "var(--portal-yellow)" }}>
        <span>DIM: C-137</span>
        <span>RESONANCE: <b>{resonance}</b> Hz</span>
        <span>STABILITY: 99.8%</span>
      </div>
    </div>
  );
}
