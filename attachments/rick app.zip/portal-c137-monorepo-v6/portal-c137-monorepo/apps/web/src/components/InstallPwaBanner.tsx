import React, { useEffect, useState } from "react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

/**
 * Kyrexis Woven PWA Install Banner.
 * Captures beforeinstallprompt and renders a golden install bar.
 */
export const InstallPwaBanner: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [visible, setVisible] = useState(false);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setVisible(true);
    };
    window.addEventListener("beforeinstallprompt", handler);
    window.addEventListener("appinstalled", () => {
      setInstalled(true);
      setVisible(false);
    });
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const install = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setInstalled(true);
      setVisible(false);
    }
    setDeferredPrompt(null);
  };

  if (!visible || installed) return null;

  return (
    <div
      id="pwa-install-bar"
      style={{
        position: "fixed",
        top: 12,
        right: 12,
        zIndex: 9999,
        display: "flex",
        gap: "0.75rem",
        alignItems: "center",
        padding: "0.6rem 1rem",
        border: "1px solid #00ff88",
        borderRadius: 10,
        background: "#020b05",
        color: "#FFD700",
        fontFamily: "system-ui, sans-serif",
      }}
    >
      <span style={{ fontWeight: 700 }}>Install Portal C-137</span>
      <button
        onClick={install}
        style={{
          background: "#FFD700",
          color: "#000",
          fontWeight: 700,
          border: 0,
          borderRadius: 6,
          padding: "0.45rem 0.9rem",
          cursor: "pointer",
        }}
      >
        INSTALL
      </button>
      <button
        onClick={() => setVisible(false)}
        style={{ background: "none", border: 0, color: "inherit", cursor: "pointer" }}
        aria-label="Dismiss"
      >
        ✕
      </button>
    </div>
  );
};
