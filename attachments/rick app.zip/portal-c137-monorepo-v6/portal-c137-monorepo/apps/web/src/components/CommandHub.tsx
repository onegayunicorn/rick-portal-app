import React, { useState } from "react";

interface Props {
  onSend: (message: string) => void;
}

export function CommandHub({ onSend }: Props) {
  const [input, setInput] = useState("");

  const handleMic = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      console.warn("Web Speech API not supported. Type command manually.");
      return;
    }
    const recognition = new SR();
    recognition.continuous = false;
    recognition.onresult = (e: any) => {
      const text = e.results[0][0].transcript;
      setInput(text);
    };
    recognition.start();
  };

  const submit = () => {
    const val = input.trim();
    if (!val) return;
    onSend(val);
    setInput("");
  };

  return (
    <div className="flex flex-col gap-2.5">
      <div
        className="flex rounded-full px-1.5 py-1 items-center"
        style={{
          background: "rgba(2,20,9,0.85)",
          border: "1px solid var(--portal-green)",
          boxShadow: "0 0 15px rgba(0,255,136,0.2)",
        }}
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder="Type or speak to your twin..."
          className="flex-1 bg-transparent border-none outline-none text-white text-[13px] px-3.5 py-2"
          style={{ fontFamily: "var(--font-mono)" }}
        />
        <button className="action-icon-btn" onClick={handleMic} title="Voice Input">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 14a3 3 0 003-3V5a3 3 0 10-6 0v6a3 3 0 003 3zm5-3a5 5 0 01-10 0H5a7 7 0 006 6.92V21h2v-3.08A7 7 0 0019 11h-2z"/></svg>
        </button>
        <button className="action-icon-btn" style={{ marginLeft: 4 }} onClick={submit} title="Send">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
        </button>
      </div>
    </div>
  );
}
