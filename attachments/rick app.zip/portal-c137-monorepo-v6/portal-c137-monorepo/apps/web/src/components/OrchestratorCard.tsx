import React from "react";
import { WaveformBar } from "@portal/hud-overlay-system";

interface Props {
  terminalText: string;
  onFire: () => void;
  onPin: () => void;
  onCollapse: () => void;
  analyser: AnalyserNode | null;
}

export function OrchestratorCard({ terminalText, onFire, onPin, onCollapse, analyser }: Props) {
  return (
    <div
      className="rounded-md p-4 relative"
      style={{
        background: "rgba(2,18,8,0.75)",
        backdropFilter: "blur(8px)",
        border: "1px solid var(--portal-green)",
        boxShadow: "0 0 25px rgba(0,255,136,0.15)",
      }}
    >
      <div
        className="flex justify-between items-center mb-2.5 text-xs font-bold pb-1.5"
        style={{ color: "var(--hud-cyan)", borderBottom: "1px dashed var(--hud-border)" }}
      >
        <span>TWIN PORTAL // TELEMETRY</span>
        <span>ACTIVE</span>
      </div>
      <div
        className="text-[13px] leading-relaxed min-h-[50px]"
        style={{ color: "#fff", textShadow: "0 0 4px rgba(255,255,255,0.4)" }}
      >
        {terminalText}
      </div>
      <WaveformBar analyser={analyser} />
      <div className="flex gap-2 mt-3.5 flex-wrap">
        <button className="hud-btn" onClick={onFire}>FIRE PORTAL</button>
        <button className="hud-btn" onClick={onPin}>PIN</button>
        <button className="hud-btn" id="btn-gist">EXPORT GIST</button>
        <button className="hud-btn hud-btn-danger" onClick={onCollapse}>COLLAPSE</button>
      </div>
    </div>
  );
}
