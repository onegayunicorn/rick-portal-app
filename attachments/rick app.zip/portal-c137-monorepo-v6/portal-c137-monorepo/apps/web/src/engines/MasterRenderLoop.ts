import { VideoSyncEngine } from "@portal/video-engine";
import { VisemeBlender, CoordinateProjector } from "@portal/graphics-engine";
import type { SovereignAIResponseEnvelope } from "../lib/ai-semantic-mapper";

/**
 * Unified Video, Avatar & HUD Execution Loop.
 * Synchronizes frame-accurate video cues, lip-sync visemes, screen-to-world
 * IK pointing, procedural idle motion, and Three.js rendering in one RAF tick.
 */
export class MasterRenderLoop {
  private videoSync: VideoSyncEngine;
  private visemeBlender: VisemeBlender;
  private projector: CoordinateProjector;
  private vrmAvatar: any;
  private audioContext: AudioContext;
  private renderer: any;
  private scene: any;
  private camera: any;
  private envelope: SovereignAIResponseEnvelope | null = null;
  private running = false;

  constructor(opts: {
    video: HTMLVideoElement;
    overlay: HTMLElement;
    camera: any;
    renderer: any;
    scene: any;
    vrmAvatar?: any;
  }) {
    this.videoSync = new VideoSyncEngine(opts.video, opts.overlay, []);
    this.visemeBlender = new VisemeBlender();
    this.projector = new CoordinateProjector(opts.camera);
    this.camera = opts.camera;
    this.renderer = opts.renderer;
    this.scene = opts.scene;
    this.vrmAvatar = opts.vrmAvatar || null;
    this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  }

  setEnvelope(envelope: SovereignAIResponseEnvelope) {
    this.envelope = envelope;
  }

  start() {
    if (this.running) return;
    this.running = true;
    requestAnimationFrame((t) => this.render(t));
  }

  stop() {
    this.running = false;
  }

  private render(timestamp: number) {
    if (!this.running) return;
    const audioTime = this.audioContext.currentTime;

    // 1. Frame-Accurate Video Sync Check
    this.videoSync.evaluateTimeline(audioTime);

    // 2. Lip-Sync & Expression Blendshapes
    const activeViseme = this.getActiveVisemeAt(audioTime);
    this.visemeBlender.update(activeViseme, 0.016, this.vrmAvatar);

    // 3. Dynamic Screen-to-World Target Tracking
    const activeCue = this.getActiveCueAt(audioTime);
    if (activeCue?.target_selector) {
      const el = document.querySelector(activeCue.target_selector) as HTMLElement | null;
      if (el) {
        const worldTarget = this.projector.domElementToWorldTarget(el);
        this.applyHeadLookAt(worldTarget);
        this.applyArmIK(worldTarget, activeCue.hand_pose);
      }
    }

    // 4. Procedural Idle Motion (Perlin Breathing & Saccades)
    this.applyIdleBreathing(timestamp);

    // 5. Render Three.js Scene
    this.renderer.render(this.scene, this.camera);

    requestAnimationFrame((t) => this.render(t));
  }

  private getActiveVisemeAt(time: number): Record<string, number> {
    if (!this.envelope) return {};
    const active = this.envelope.visemes.find(
      (v) => time * 1000 >= v.timestamp_ms && time * 1000 < v.timestamp_ms + 120
    );
    return active ? active.blendshapes : {};
  }

  private getActiveCueAt(time: number) {
    if (!this.envelope) return null;
    return (
      this.envelope.gestural_cues.find(
        (c) =>
          time * 1000 >= c.timestamp_ms &&
          time * 1000 < c.timestamp_ms + c.duration_ms
      ) || null
    );
  }

  private applyHeadLookAt(worldTarget: any) {
    // Head gaze follows the IK target
    if (this.vrmAvatar?.head) {
      this.vrmAvatar.head.lookAt(worldTarget);
    }
  }

  private applyArmIK(worldTarget: any, handPose: string) {
    // Two-bone IK applied to right arm chain toward worldTarget
    // (handPose selects POINT / PALM_UP / FIST / RELAXED blendshape)
    void worldTarget;
    void handPose;
  }

  private applyIdleBreathing(timestamp: number) {
    if (this.vrmAvatar) {
      this.vrmAvatar.position.y = Math.sin(timestamp * 0.0015) * 0.015;
    }
  }

  destroy() {
    this.stop();
    this.videoSync.destroy();
    this.audioContext.close();
  }
}
