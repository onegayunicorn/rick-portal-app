/**
 * Structured AI Output Schema with Kinetic Cue Tags.
 *
 * The LLM orchestration layer is prompted to return structured JSON envelopes
 * carrying synchronized gestural and acoustic metadata for the avatar twin.
 */
export interface SovereignAIResponseEnvelope {
  transcript: string;
  audio_url: string;
  duration_ms: number;
  visemes: Array<{
    timestamp_ms: number;
    phoneme: string;
    blendshapes: { [name: string]: number };
  }>;
  gestural_cues: Array<{
    timestamp_ms: number;
    duration_ms: number;
    gesture_type: "POINT_AT_DOM" | "WAVE" | "EMPHASIZE" | "RELOAD_PORTAL";
    target_selector?: string; // e.g. "#resonance-val"
    emotion: "NEUTRAL" | "CONFIDENT" | "ALERT" | "AMUSED";
    hand_pose: "POINT" | "PALM_UP" | "FIST" | "RELAXED";
  }>;
}

/**
 * Prompt Specification for Gesture Injection:
 *
 * "You are the Rick C-137 Portal Orchestrator. Respond to the user's query in character.
 * In addition to the verbal response, annotate your reply with JSON kinetic cues indicating:
 *  1. When to point at HUD telemetry elements (e.g. target_selector: "#resonance-val").
 *  2. Emotional shifts (e.g. emotion: "ALERT" when dimensional stability drops).
 *  3. Hand pose specifications for the 3D twin avatar."
 */
export const GESTURE_INJECTION_SYSTEM_PROMPT = `You are the Rick C-137 Portal Orchestrator. Respond to the user's query in character. In addition to the verbal response, annotate your reply with JSON kinetic cues indicating:
1. When to point at HUD telemetry elements (e.g. target_selector: "#resonance-val").
2. Emotional shifts (e.g. emotion: "ALERT" when dimensional stability drops).
3. Hand pose specifications for the 3D twin avatar.`;
