import React, { useState, useEffect, useRef } from "react";
import { TelemetryHeader } from "./components/TelemetryHeader";
import { OrchestratorCard } from "./components/OrchestratorCard";
import { CommandHub } from "./components/CommandHub";
import { VortexCanvas } from "@portal/graphics-engine";
import { ScanlineFilter } from "@portal/hud-overlay-system";
import { SovereignAIEngine } from "@portal/offline-ai";
import { useWebAudio } from "./hooks/useWebAudio";

export function App() {
  const [resonance, setResonance] = useState(1207);
  const [terminalText, setTerminalText] = useState(
    "Portal test complete. Structure stable. You're clear to proceed."
  );
  const [aiEngineReady, setAiEngineReady] = useState(false);
  const aiEngineRef = useRef<SovereignAIEngine | null>(null);
  const { analyser, playPortalSound } = useWebAudio();

  // Initialize sovereign offline AI engine (WebGPU) on mount
  useEffect(() => {
    const engine = new SovereignAIEngine();
    aiEngineRef.current = engine;
    engine
      .init((report) => {
        console.log(`[Portal AI] Loading model: ${Math.round(report.progress * 100)}%`);
      })
      .then(() => setAiEngineReady(true))
      .catch((err) => console.warn("[Portal AI] WebGPU unavailable, fallback mode:", err));
    return () => {
      engine?.dispose?.();
    };
  }, []);

  const handleFire = () => {
    playPortalSound(1207, "sawtooth");
    const newRes = Math.floor(1000 + Math.random() * 800);
    setResonance(newRes);
    setTerminalText(
      `Firing fluid injector. Microverse battery discharging at ${newRes} Hz. Dimensional rift opened.`
    );
  };

  const handlePin = () => {
    playPortalSound(880, "sine");
    setTerminalText(`Coordinate C-137 [Resonance: ${resonance} Hz] pinned to local warp memory.`);
  };

  const handleCollapse = () => {
    playPortalSound(180, "triangle");
    setTerminalText("Portal event horizon collapsed. Standing by for recalibration.");
  };

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <div
        id="hud-container"
        className="relative w-full max-w-[440px] h-full max-h-[880px] overflow-hidden flex flex-col justify-between"
        style={{
          background:
            "radial-gradient(circle at center, rgba(0,40,15,0.4) 0%, rgba(1,10,4,0.95) 100%)",
          border: "1px solid var(--hud-border)",
          boxShadow: "0 0 40px rgba(0,255,136,0.2)",
        }}
      >
        {/* Layer 1: WebGL Vortex Background */}
        <VortexCanvas resonance={resonance} analyser={analyser} />

        {/* Layer 2: CRT Scanline Overlay */}
        <ScanlineFilter />

        {/* Layer 3: Interactive HUD */}
        <div className="relative z-10 flex flex-col h-full justify-between p-4">
          <TelemetryHeader resonance={resonance} aiReady={aiEngineReady} />
          <OrchestratorCard
            terminalText={terminalText}
            onFire={handleFire}
            onPin={handlePin}
            onCollapse={handleCollapse}
            analyser={analyser}
          />
          <CommandHub
            onSend={(msg) => {
              playPortalSound(750, "sawtooth");
              setTerminalText(`Dispatched to Orchestrator: "${msg}"`);
            }}
          />
        </div>
      </div>
    </div>
  );
}
