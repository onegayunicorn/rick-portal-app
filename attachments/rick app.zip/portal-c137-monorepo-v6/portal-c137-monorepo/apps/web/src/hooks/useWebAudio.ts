import { useRef, useCallback } from "react";

export function useWebAudio() {
  const ctxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);

  const initAudio = useCallback(() => {
    if (!ctxRef.current) {
      const Ctx = window.AudioContext || (window as any).webkitAudioContext;
      ctxRef.current = new Ctx();
      analyserRef.current = ctxRef.current.createAnalyser();
      analyserRef.current.fftSize = 64;
    }
    return { ctx: ctxRef.current!, analyser: analyserRef.current! };
  }, []);

  const playPortalSound = useCallback(
    (freq = 440, type: OscillatorType = "sawtooth") => {
      const { ctx, analyser } = initAudio();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 2.5, ctx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(analyser);
      analyser.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    },
    [initAudio]
  );

  return { analyser: analyserRef.current, playPortalSound, initAudio };
}
