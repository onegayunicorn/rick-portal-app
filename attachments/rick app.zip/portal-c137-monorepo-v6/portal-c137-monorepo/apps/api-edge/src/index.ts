import { Hono } from "hono";
import { serve } from "@hono/node-server";
import { GistSyncClient } from "@portal/gist-sync";
import { MatrixTwinSync } from "@portal/matrix-protocol";

const app = new Hono();

// Health check
app.get("/health", (c) => c.json({ status: "SOVEREIGN_EDGE_ONLINE", dimension: "C-137" }));

// Gist proxy - allows anonymous gist creation without exposing client tokens
app.post("/api/gist/export", async (c) => {
  try {
    const body = await c.req.json();
    const client = new GistSyncClient(process.env.GITHUB_GIST_TOKEN);
    const url = await client.exportPortalState(body.payload, body.isPublic ?? false);
    return c.json({ ok: true, gistUrl: url });
  } catch (err: any) {
    return c.json({ ok: false, error: err.message }, 500);
  }
});

// Matrix federation proxy
app.post("/api/matrix/sync", async (c) => {
  try {
    const body = await c.req.json();
    const sync = new MatrixTwinSync(process.env.MATRIX_HOMESERVER_URL);
    const result = await sync.broadcastTelemetry(body.roomId, body.event);
    return c.json({ ok: true, eventId: result });
  } catch (err: any) {
    return c.json({ ok: false, error: err.message }, 500);
  }
});

const port = Number(process.env.PORT) || 3001;
console.log(`[Portal Edge] Sovereign API running on :${port}`);
serve({ fetch: app.fetch, port });
