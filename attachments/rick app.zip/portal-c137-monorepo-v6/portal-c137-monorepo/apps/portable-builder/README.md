# PortableApps (PAF) Builder UI

Tkinter 5-panel GUI for generating compliant PortableApps.com bundles.

```bash
python3 apps/portable-builder/builder_ui.py
```

Panels:
1. App Metadata (name, version, publisher, category, executable, output dir)
2. Package & Build (generates App/, Data/, Other/, appinfo.ini, launchers, SHA256)
