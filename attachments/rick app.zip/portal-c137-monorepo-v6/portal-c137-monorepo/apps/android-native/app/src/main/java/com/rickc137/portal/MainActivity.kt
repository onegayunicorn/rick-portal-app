package com.rickc137.portal

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import com.rickc137.portal.security.HardenedSovereignBridge
import java.security.SecureRandom

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var sessionKey: ByteArray

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Generate ephemeral session key for zero-trust bridge HMAC
        sessionKey = ByteArray(32)
        SecureRandom().nextBytes(sessionKey)

        webView = WebView(this)
        setContentView(webView)

        // 1. Configure Hardened Sovereign Web Environment
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false       // Prevent arbitrary file traversal
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = false
        }

        // 2. Intercept and Serve Assets under Secure Origin (No CORS/Mixed Content)
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
        }

        // 3. Register Native Hardware Bridge (zero-trust, HMAC-SHA256 signed)
        webView.addJavascriptInterface(
            HardenedSovereignBridge(this, sessionKey),
            "SovereignBridge"
        )

        // 4. Load the Offline PWA Bundle
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
