# Android Native Web Assets

Place the built PWA bundle (`apps/web/dist/*`) into this `assets/` directory.
The `WebViewAssetLoader` serves them under the secure origin
`https://appassets.androidplatform.net/assets/` with zero CORS / mixed-content issues.
