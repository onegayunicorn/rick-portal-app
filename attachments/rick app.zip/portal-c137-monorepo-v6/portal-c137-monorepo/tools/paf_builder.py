#!/usr/bin/env python3
# PortableApp (PAF) Builder.
# Generates a compliant PortableApps.com .zip distribution from a built web bundle.
#
# Usage:
#     python3 tools/paf_builder.py --source ./apps/web/dist --output ./Builds/RickPortalPortable_1.0.0.zip
import argparse, hashlib, os, zipfile, sys

def main():
    parser = argparse.ArgumentParser(description="Build PortableApp (PAF) package")
    parser.add_argument("--source", required=True, help="Path to built web bundle (e.g. apps/web/dist)")
    parser.add_argument("--output", default="Builds/RickPortalPortable_1.0.0.zip", help="Output zip path")
    args = parser.parse_args()

    if not os.path.isdir(args.source):
        print("ERROR: source directory not found: " + args.source, file=sys.stderr)
        sys.exit(1)

    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
    portable_root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "portable-app")

    with zipfile.ZipFile(args.output, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(portable_root):
            for f in files:
                full = os.path.join(root, f)
                arc = os.path.relpath(full, portable_root)
                zf.write(full, arc)
        for root, _, files in os.walk(args.source):
            for f in files:
                full = os.path.join(root, f)
                arc = os.path.join("App", "portal-web", os.path.relpath(full, args.source))
                zf.write(full, arc)

    sha = hashlib.sha256()
    with open(args.output, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha.update(chunk)
    sha_path = args.output + ".sha256"
    with open(sha_path, "w") as f:
        f.write(sha.hexdigest() + "  " + os.path.basename(args.output) + "\n")

    print("Built: " + args.output)
    print("SHA256: " + sha.hexdigest())
    print("Checksum file: " + sha_path)

if __name__ == "__main__":
    main()
