@echo off
setlocal
set "PORTABLE_DIR=%~dp0"
start "" "%PORTABLE_DIR%App\portal-runtime.exe" --portable --user-data-dir="%PORTABLE_DIR%Data\settings"
endlocal
