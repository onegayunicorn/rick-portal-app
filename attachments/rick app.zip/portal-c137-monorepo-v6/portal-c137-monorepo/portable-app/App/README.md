# App/ - Core binaries & runtime bundle

Place the built web bundle or native runtime here:
- Web build: copy apps/web/dist/* into App/portal-web/
- Tauri binary: copy the release binary as App/portal-runtime.exe

Launcher scripts reference App/portal-runtime[.exe].
