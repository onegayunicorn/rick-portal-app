#!/data/data/com.termux/files/usr/bin/bash
BASEDIR="$(cd "$(dirname "$0")" && pwd)"
python3 -m http.server 8080 --directory "$BASEDIR/App" &
termux-open-url http://localhost:8080
