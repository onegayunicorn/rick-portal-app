#!/usr/bin/env bash
BASEDIR="$(cd "$(dirname "$0")" && pwd)"
chmod +x "$BASEDIR/App/portal-runtime" 2>/dev/null
"$BASEDIR/App/portal-runtime" --portable --user-data-dir="$BASEDIR/Data/settings" "$@"
