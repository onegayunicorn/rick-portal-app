# Sovereign AI Portal Interface: Production Monorepo & Deployment Blueprint
**Target System:** Rick C-137 Interactive Twin Portal & Multi-Dimensional Orchestrator UI  
**Core Technologies:** React 19, TypeScript, Tailwind CSS, Turborepo, Node.js, 3D GLTF/GLB Engine, WebGL/WebGPU Shaders, Prisma, Drizzle, GitHub Gists, Vercel & Docker  
**Revision:** 2.0.0 (Enterprise Production Specification)

---

## 1. Executive System Overview & Interface Deconstruction

This document establishes the architecture for turning the captured mobile HUD interfaces (`VID_20261001_214700.mp4`, `VID_20261001_214835.mp4`, and `VID_20261001_215022.mp4`) into an interactive, sovereign AI interface operating across Web (PWA), Desktop, Mobile, and Edge.

### 1.1 Deconstructed Interface Elements
1. **Dynamic Top Navigation & Telemetry:**
   - Real-time dimensional frequency, battery voltage, signal mesh strength.
   - Title display: `RICK C-137 PORTAL INTERFACE // TWIN PORTAL`.
   - Dimension coordinate indicator (`1207 / 1207`, `Stability: 99.87%`).
2. **3D GLTF/GLB & WebGL/WebGPU Graphics Engine:**
   - Interactive 3D Portal Gun rendered in real-time with metallic PBR materials and glowing liquid portal fluid chambers.
   - Audio-reactive swirling particle accretion vortex behind the 3D model.
   - Post-processing CRT scanlines, chromatic aberration, and holographic bloom.
3. **Orchestrator Card & Action Trays:**
   - Central interactive holographic panel displaying state: `ORCHESTRATOR ONLINE`, `ACTIVE`.
   - Dynamic terminal readout: `"Portal test complete. Structure stable. You're clear to proceed."`
   - Actions: `Pin`, `Delete`, `Retest`, `Recalibrate`, `Transmit via Gist`.
4. **Multimodal Twin Command Hub:**
   - Floating glassmorphic capsule: `"Type or speak to your twin..."`
   - Real-time audio waveform visualizer tied to local Speech-to-Text (STT) and local Text-to-Speech (TTS).
5. **Decentralized State & Telemetry Storage:**
   - Dual ORM setup: **Drizzle ORM** for zero-latency local SQLite/WASM and Edge runtimes, and **Prisma ORM** for persistent multi-tenant PostgreSQL backends.
   - **GitHub Gist API** for sovereign, serverless sharing of dimension coordinates, prompt workflows, and system snapshots.

---

## 2. Turborepo Monorepo Architecture & Package Topology

The repository is organized using **Turborepo**, **pnpm workspaces**, and **TypeScript 5.6+** to ensure zero code duplication and blazing fast build caching.

```
sovereign-portal-monorepo/
├── .github/
│   └── workflows/
│       ├── ci-lint-test.yml
│       ├── deploy-vercel.yml
│       ├── deploy-docker.yml
│       └── release-native.yml
├── apps/
│   ├── web/                       # React 19 + Vite / TanStack Start PWA
│   │   ├── public/
│   │   │   ├── models/            # 3D GLTF/GLB assets & quantized AI models
│   │   │   ├── shaders/           # GLSL Shaders (vertex, fragment, post)
│   │   │   ├── manifest.json      # PWA App Manifest
│   │   │   └── sw.ts              # Service Worker (Range-request caching for GLB & models)
│   │   ├── src/
│   │   │   ├── components/        # React HUD components & 3D canvas
│   │   │   ├── hooks/             # WebAudio, WebGPU, and Gist hooks
│   │   │   └── main.tsx
│   │   ├── Dockerfile             # Multi-stage production container
│   │   └── vercel.json            # Vercel Edge configuration with COOP/COEP headers
│   ├── api-edge/                  # Node.js / Edge microservice for Matrix/Gist proxies
│   ├── desktop-tauri/             # Tauri v2 wrapper (Rust + React Webview)
│   └── mobile-capacitor/          # Capacitor 6 wrapper (iOS & Android)
├── packages/
│   ├── graphics-engine/           # Three.js / React Three Fiber 3D GLB & WebGL pipeline
│   │   ├── src/
│   │   │   ├── PortalGunModel.tsx # GLB loader, portal fluid shaders, kinematics
│   │   │   ├── VortexCanvas.tsx   # Audio-reactive swirl shader & particle engine
│   │   │   ├── PostProcessing.tsx # Bloom, chromatic aberration, scanline pass
│   │   │   └── shaders/
│   ├── database/                  # Unified database layer (Prisma + Drizzle)
│   │   ├── prisma/
│   │   │   └── schema.prisma      # Central PostgreSQL relational schema
│   │   ├── drizzle/
│   │   │   ├── schema.ts          # Edge & SQLite local schema definitions
│   │   │   └── migrations/
│   │   ├── src/
│   │   │   ├── prisma-client.ts   # Node.js / Serverless Prisma client
│   │   │   ├── drizzle-client.ts  # Edge / LibSQL / SQLite-WASM Drizzle client
│   │   │   └── sync-engine.ts     # Two-way sync between local Drizzle & cloud Prisma
│   ├── gist-sync/                 # GitHub Gist export/import & state sharing
│   │   ├── src/
│   │   │   ├── gist-client.ts     # Authenticated & anonymous Gist generator
│   │   │   └── coordinate-pack.ts # Serialization of portal states to Gist JSON
│   ├── offline-ai/                # Local WebGPU inference (WebLLM, Whisper, Kokoro)
│   ├── hud-overlay-system/        # Tailwind-styled cybernetic HUD widgets
│   ├── ui-core/                   # Shared Tailwind preset, tokens, sound FX
│   └── tsconfig/                  # Base TypeScript configurations
├── pnpm-workspace.yaml
├── turbo.json
└── package.json
```

### 2.1 Turborepo Pipeline Configuration (`turbo.json`)
```json
{
  "$schema": "https://turbo.build/schema.json",
  "tasks": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": ["dist/**", ".next/**", "build/**"],
      "env": [
        "DATABASE_URL",
        "DIRECT_URL",
        "GITHUB_GIST_TOKEN",
        "NEXT_PUBLIC_WEBGPU_MODELS_URL"
      ]
    },
    "db:generate": {
      "cache": false
    },
    "db:push": {
      "cache": false
    },
    "lint": {
      "dependsOn": ["^build"]
    },
    "dev": {
      "cache": false,
      "persistent": true
    }
  }
}
```

---

## 3. 3D GLB & Graphics Engine (`packages/graphics-engine`)

The portal interface features an interactive 3D portal gun model combined with an audio-reactive particle vortex.

### 3.1 Portal Gun Model Loader & Fluid Shader (`PortalGunModel.tsx`)
```tsx
import React, { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { useGLTF } from "@react-three/drei";
import * as THREE from "three";

interface PortalGunProps {
  resonance: number; // Audio resonance frequency (0.0 - 1.0)
  firing: boolean;
}

export function PortalGunModel({ resonance, firing }: PortalGunProps) {
  // Load 3D GLB model asset
  const { scene, materials } = useGLTF("/models/rick_portal_gun.glb") as any;
  const gunRef = useRef<THREE.Group>(null);
  const fluidMaterialRef = useRef<THREE.ShaderMaterial>(null);

  // Floating idle animation + firing recoil
  useFrame((state, delta) => {
    if (!gunRef.current) return;
    const time = state.clock.getElapsedTime();
    gunRef.current.position.y = Math.sin(time * 2.0) * 0.05 + (firing ? -0.1 : 0);
    gunRef.current.rotation.z = Math.sin(time * 1.5) * 0.02;

    // Pulse internal portal fluid emission based on resonance
    if (materials["PortalLiquid"]) {
      materials["PortalLiquid"].emissiveIntensity = 2.0 + resonance * 5.0;
      materials["PortalLiquid"].emissive = new THREE.Color(
        firing ? 0xffcc00 : 0x00ff88
      );
    }
  });

  return (
    <group ref={gunRef} scale={[1.8, 1.8, 1.8]} position={[0, -0.6, 0]}>
      <primitive object={scene} />
    </group>
  );
}

useGLTF.preload("/models/rick_portal_gun.glb");
```

### 3.2 Post-Processing & Scanline Pipeline (`PostProcessing.tsx`)
```tsx
import React from "react";
import { EffectComposer, Bloom, ChromaticAberration, Scanline } from "@react-three/postprocessing";
import { BlendFunction } from "postprocessing";
import * as THREE from "three";

export function GraphicsPipelineEffects({ active }: { active: boolean }) {
  if (!active) return null;

  return (
    <EffectComposer>
      {/* Rick Portal Neon Glow */}
      <Bloom
        intensity={1.5}
        luminanceThreshold={0.2}
        luminanceSmoothing={0.9}
        blendFunction={BlendFunction.SCREEN}
      />
      {/* Dimensional Aberration */}
      <ChromaticAberration
        offset={new THREE.Vector2(0.002, 0.002)}
        radialModulation={false}
        modulationOffset={0.15}
      />
      {/* Holographic Scanlines */}
      <Scanline
        density={2.5}
        opacity={0.12}
        blendFunction={BlendFunction.OVERLAY}
      />
    </EffectComposer>
  );
}
```

---

## 4. Dual Database Architecture: Prisma & Drizzle ORM

To achieve sovereign offline operation with cloud synchronization, the system implements a dual-ORM strategy:
- **Drizzle ORM:** Ultra-lightweight SQL driver used client-side inside the browser via `sqlite-wasm` and at the Edge via Cloudflare D1 / Turso (zero bundle bloat).
- **Prisma ORM:** High-performance type-safe ORM for the Node.js production backend, handling complex relations, migrations, and PostgreSQL pooling.

### 4.1 Prisma Schema (`packages/database/prisma/schema.prisma`)
```prisma
datasource db {
  provider  = "postgresql"
  url       = env("DATABASE_URL")
  directUrl = env("DIRECT_URL")
}

generator client {
  provider = "prisma-client-js"
}

model DimensionCoordinate {
  id            String   @id @default(uuid())
  dimensionCode String   @unique // e.g. "C-137", "J-19Z7"
  stability     Float    @default(1.0)
  resonanceHz   Int      @default(1207)
  status        String   @default("ACTIVE") // ACTIVE, DORMANT, COLLAPSED
  gistUrl       String?
  telemetryLogs Json?
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  telemetries   TelemetryRecord[]

  @@index([dimensionCode])
}

model TelemetryRecord {
  id           String              @id @default(uuid())
  coordinateId String
  coordinate   DimensionCoordinate @relation(fields: [coordinateId], references: [id], onDelete: Cascade)
  actor        String              // "ORCHESTRATOR", "TWIN_AGENT", "USER"
  message      String
  meta         Json?
  timestamp    DateTime            @default(now())
}
```

### 4.2 Drizzle Schema (`packages/database/drizzle/schema.ts`)
```typescript
import { sqliteTable, text, real, integer } from "drizzle-orm/sqlite-core";

export const localCoordinates = sqliteTable("local_coordinates", {
  id: text("id").primaryKey(),
  dimensionCode: text("dimension_code").notNull().unique(),
  stability: real("stability").default(1.0).notNull(),
  resonanceHz: integer("resonance_hz").default(1207).notNull(),
  status: text("status").default("ACTIVE").notNull(),
  gistUrl: text("gist_url"),
  syncedToCloud: integer("synced_to_cloud", { mode: "boolean" }).default(false).notNull(),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull(),
});

export const localTelemetryLogs = sqliteTable("local_telemetry_logs", {
  id: text("id").primaryKey(),
  coordinateId: text("coordinate_id").references(() => localCoordinates.id),
  actor: text("actor").notNull(),
  message: text("message").notNull(),
  timestamp: integer("timestamp", { mode: "timestamp" }).notNull(),
});
```

---

## 5. GitHub Gist Integration (`packages/gist-sync`)

The system enables users to export dimension coordinates, orchestrator logs, and neural configurations to sovereign GitHub Gists without vendor lock-in.

### 5.1 Gist Synchronization Service (`gist-client.ts`)
```typescript
export interface PortalGistPayload {
  dimension: string;
  resonance: number;
  stability: number;
  orchestratorLogs: Array<{ actor: string; text: string; time: string }>;
  offlineModelConfig: {
    model: string;
    temperature: number;
  };
}

export class GistSyncClient {
  private token: string | null;

  constructor(token?: string) {
    this.token = token || process.env.GITHUB_GIST_TOKEN || null;
  }

  async exportPortalState(payload: PortalGistPayload, isPublic = false): Promise<string> {
    const filename = `portal-${payload.dimension.toLowerCase().replace(/[^a-z0-9]/g, "-")}.json`;
    const headers: Record<string, string> = {
      "Accept": "application/vnd.github+json",
      "Content-Type": "application/json",
    };

    if (this.token) {
      headers["Authorization"] = `Bearer ${this.token}`;
    }

    const body = {
      description: `Rick C-137 Portal Coordinate & Orchestrator Snapshot: ${payload.dimension}`,
      public: isPublic,
      files: {
        [filename]: {
          content: JSON.stringify(payload, null, 2),
        },
      },
    };

    const res = await fetch("https://api.github.com/gists", {
      method: "POST",
      headers,
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      throw new Error(`Failed to create Gist: ${res.statusText}`);
    }

    const data = await res.json();
    return data.html_url; // Direct Gist URL
  }

  async importPortalState(gistId: string): Promise<PortalGistPayload> {
    const res = await fetch(`https://api.github.com/gists/${gistId}`);
    if (!res.ok) throw new Error("Gist not found or unreachable");

    const data = await res.json();
    const firstFile = Object.values(data.files)[0] as { content: string };
    return JSON.parse(firstFile.content) as PortalGistPayload;
  }
}
```

---

## 6. Complete Deployment Instructions

### 6.1 Vercel Production Deployment

Vercel provides global Edge network hosting for the React 19 PWA front-end with HTTP Cross-Origin Isolation headers required for **WebGPU SharedArrayBuffer** execution.

#### 1. Configure Vercel Edge Headers (`apps/web/vercel.json`)
```json
{
  "framework": "vite",
  "buildCommand": "cd ../.. && pnpm --filter @portal/web build",
  "outputDirectory": "dist",
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "Cross-Origin-Opener-Policy", "value": "same-origin" },
        { "key": "Cross-Origin-Embedder-Policy", "value": "require-corp" },
        { "key": "X-Frame-Options", "value": "DENY" },
        { "key": "X-Content-Type-Options", "value": "nosniff" }
      ]
    },
    {
      "source": "/models/(.*)",
      "headers": [
        { "key": "Cache-Control", "value": "public, max-age=31536000, immutable" },
        { "key": "Accept-Ranges", "value": "bytes" }
      ]
    }
  ]
}
```

#### 2. Deploy via Vercel CLI
```bash
# Link project to Vercel
pnpm dlx vercel link

# Inject Environment Variables
pnpm dlx vercel env add DATABASE_URL production
pnpm dlx vercel env add GITHUB_GIST_TOKEN production

# Execute Production Deployment with Turborepo Remote Caching
pnpm dlx vercel --prod
```

---

### 6.2 Docker Sovereign Production Deployment

For complete infrastructure sovereignty (self-hosting on bare-metal, VPS, Hetzner, AWS EC2, or home-lab hardware), the application is packaged in a multi-stage Docker container.

#### 1. Multi-Stage Production Dockerfile (`apps/web/Dockerfile`)
```dockerfile
# Stage 1: Pruning Monorepo with Turbo
FROM node:22-alpine AS pruner
RUN apk add --no-cache libc6-compat
WORKDIR /app
RUN npm install --global turbo
COPY . .
RUN turbo prune --scope=@portal/web --docker

# Stage 2: Install dependencies & build
FROM node:22-alpine AS builder
RUN apk add --no-cache libc6-compat
WORKDIR /app

RUN corepack enable && corepack prepare pnpm@9.12.0 --activate

COPY .gitignore .gitignore
COPY --from=pruner /app/out/json/ .
COPY --from=pruner /app/out/pnpm-lock.yaml ./pnpm-lock.yaml
RUN pnpm install --frozen-lockfile

COPY --from=pruner /app/out/full/ .
COPY turbo.json turbo.json

ENV NODE_ENV=production
RUN pnpm --filter @portal/database run db:generate
RUN pnpm --filter @portal/web build

# Stage 3: Lightweight Nginx Production Runner
FROM nginx:alpine AS runner
WORKDIR /usr/share/nginx/html

# Clean default Nginx files
RUN rm -rf ./*

# Copy built artifacts from builder
COPY --from=builder /app/apps/web/dist .

# Copy hardened Nginx configuration with WebGPU headers
COPY apps/web/nginx.conf /etc/nginx/conf.d/default.conf

EXPOSE 80 443

HEALTHCHECK --interval=30s --timeout=3s --retries=3   CMD wget --quiet --tries=1 --spider http://localhost:80/ || exit 1

CMD ["nginx", "-g", "daemon off;"]
```

#### 2. Nginx Hardened Configuration (`apps/web/nginx.conf`)
```nginx
server {
    listen 80;
    server_name _;
    root /usr/share/nginx/html;
    index index.html;

    # Gzip and Brotli compression for large 3D models and WASM
    gzip on;
    gzip_types text/plain text/css application/json application/javascript application/wasm model/gltf-binary;

    # Security & Cross-Origin Isolation for WebGPU
    add_header Cross-Origin-Opener-Policy same-origin always;
    add_header Cross-Origin-Embedder-Policy require-corp always;
    add_header X-Frame-Options SAMEORIGIN always;

    # Static 3D models and quantized weights caching with Range requests
    location /models/ {
        expires 365d;
        add_header Cache-Control "public, no-transform, immutable";
        proxy_buffering off;
    }

    # SPA routing
    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

#### 3. Sovereign Docker Compose Orchestration (`docker-compose.yml`)
```yaml
version: '3.9'

services:
  portal-ui:
    build:
      context: .
      dockerfile: apps/web/Dockerfile
    container_name: c137_portal_ui
    ports:
      - "80:80"
    restart: unless-stopped
    environment:
      - NODE_ENV=production
    networks:
      - portal_mesh

  postgres-db:
    image: postgres:16-alpine
    container_name: c137_postgres
    environment:
      POSTGRES_DB: portal_c137
      POSTGRES_USER: rick
      POSTGRES_PASSWORD: ${DB_PASSWORD:-wubbalubbadubdub}
    volumes:
      - pgdata:/var/lib/postgresql/data
    networks:
      - portal_mesh

  matrix-dendrite:
    image: matrixdotorg/dendrite:latest
    container_name: c137_matrix
    ports:
      - "8448:8448"
    volumes:
      - matrixdata:/etc/dendrite
    networks:
      - portal_mesh

networks:
  portal_mesh:
    driver: bridge

volumes:
  pgdata:
  matrixdata:
```

#### 4. Executing Sovereign Production Deployment
```bash
# Generate environment secrets
echo "DB_PASSWORD=$(openssl rand -hex 16)" > .env

# Run database migrations with Prisma
pnpm --filter @portal/database run db:push

# Build and start all sovereign containers
docker compose up -d --build

# Verify healthy status
docker compose ps
```

---

## 7. Verification & Production Readiness Checklist

1. [x] **Turborepo Caching:** Run `turbo run build` twice; ensure second run reports `FULL TURBO` cache hits.
2. [x] **3D GLTF Asset Pipeline:** Verify `rick_portal_gun.glb` loads with DRACO/Meshopt compression (< 2MB transfer).
3. [x] **WebGPU Cross-Origin Isolation:** Confirm browser console indicates `crossOriginIsolated === true` on both Vercel and Docker Nginx deployments.
4. [x] **Dual ORM Synchronization:** Run local mutations in Drizzle (SQLite/WASM); verify background worker pushes telemetry batches to Prisma (PostgreSQL).
5. [x] **Gist Export Verification:** Trigger "Transmit via Gist" in HUD; confirm valid anonymous or token-authenticated GitHub Gist creation with JSON coordinates.