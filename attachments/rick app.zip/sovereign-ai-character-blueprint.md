# Sovereign AI Character & Portal Template (C-137 Archetype)
## Production Architecture, Implementation Blueprint & Starter Template

---

### Executive Architecture Overview

The **Sovereign AI Character & Portal Template** is an offline-capable, latency-optimized interactive avatar platform designed to deliver conversational AI through a tri-modal intelligence hierarchy:

1. **Tier 1 (Cloud Edge SSE)**: High-precision cloud LLM streamed via Server-Sent Events (SSE) through Edge AI routes for nuanced, multi-turn dialogue with deep world knowledge.
2. **Tier 2 (In-Browser WebGPU WebLLM)**: Client-side local inference powered by `@mlc-ai/web-llm` targeting Quantized Llama / SmolLM models directly in the user browser using WebGPU acceleration—zero server compute costs and zero data leakage.
3. **Tier 3 (Pocket Heuristic Engine)**: Zero-latency deterministic pattern engine executing dialect-accurate fallback responses entirely offline when WebGPU or network connections are unavailable.

```
                   +----------------------------------+
                   |     User Speech / Text Input     |
                   +-----------------+----------------+
                                     |
                                     v
                   +----------------------------------+
                   |  Unified ChatTransport Router    |
                   +-------+---------+--------+-------+
                           |         |        |
        Online & Mode=Cloud|         |Mode=GPU|Fallback / Mode=Pocket
                           v         |        v
           +-----------------------+ | +------------------------+
           | Edge SSE Gateway      | | | Instant Heuristic      |
           | (/api/chat)           | | | Pattern Engine         |
           +-----------+-----------+ | +-----------+------------+
                       |             v             |
                       |   +-------------------+   |
                       |   | WebLLM WebGPU     |   |
                       |   | In-Browser Model  |   |
                       |   +---------+---------+   |
                       |             |             |
                       +-------+-----+-------------+
                               |
                               v
                     Token / Chunk Stream
                               |
               +---------------+---------------+
               |                               |
               v                               v
    +-----------------------+      +-----------------------+
    | Character Video State |      | Pipelined Sentence    |
    | Machine (Idle/Talk)   |      | Synthesizer (TTS)     |
    +-----------------------+      +-----------------------+
               |                               |
               +---------------+---------------+
                               |
                               v
               +-------------------------------+
               | CyberHUD Audio-Visual Portal  |
               +-------------------------------+
```

---

### Architectural Tenets

- **Tri-Modal Intelligence Tiering**: The client automatically degrades gracefully from Cloud to WebLLM (if WebGPU supported) to Pocket mode without throwing unhandled connection errors.
- **Hardware-Accelerated Video Crossfader**: 3-state crossfading (`idle`, `thinking`, `talking`) with 550ms transition timeouts, keeping background videos paused to minimize GPU memory pressure and battery drain on mobile devices.
- **Pipelined Streaming Speech**: Token streams are parsed on punctuation boundaries (`[.!?…
]`), dispatching synthesized audio sentences as they form rather than blocking for full generation completion.
- **Service Worker Media Strategy**: Cache-First policy for video buffers and audio assets with byte-range request support; Network-First with cache fallback for the application shell.

---

## 1. Directory Structure

```text
ai-character-portal-template/
├── .env.example
├── Dockerfile
├── docker-compose.yml
├── package.json
├── tsconfig.json
├── vite.config.ts
├── public/
│   ├── icons/
│   │   ├── icon-192.png
│   │   └── icon-512.png
│   ├── character-poster.jpg
│   ├── manifest.webmanifest
│   └── sw.js
└── src/
    ├── assets/
    │   ├── character-idle.mp4
    │   ├── character-thinking.mp4
    │   └── character-talking.mp4
    ├── components/
    │   ├── portal/
    │   │   ├── CharacterStage.tsx
    │   │   ├── CyberHUD.tsx
    │   │   └── FloatingAvatar.tsx
    │   └── ui/
    │       ├── button.tsx
    │       └── slider.tsx
    ├── hooks/
    │   ├── use-audio-recorder.ts
    │   └── use-speech-synthesizer.ts
    ├── lib/
    │   ├── ai/
    │   │   └── responses.server.ts
    │   ├── character-persona.ts
    │   ├── character-transport.ts
    │   ├── offline-ai.ts
    │   └── utils.ts
    ├── routes/
    │   ├── api/
    │   │   └── chat.ts
    │   ├── __root.tsx
    │   └── index.tsx
    ├── router.tsx
    ├── start.ts
    └── styles.css
```

---

## 2. Configuration & Runtime Manifests

### `package.json`
```json
{
  "name": "ai-character-portal-template",
  "version": "1.0.0",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "vite dev",
    "build": "vite build",
    "preview": "vite preview",
    "lint": "eslint .",
    "typecheck": "tsc --noEmit"
  },
  "dependencies": {
    "@ai-sdk/openai": "^4.0.78",
    "@ai-sdk/react": "^4.0.125",
    "@mlc-ai/web-llm": "^0.2.85",
    "@tailwindcss/vite": "^4.2.1",
    "@tanstack/react-query": "^5.101.1",
    "@tanstack/react-router": "1.170.41",
    "@tanstack/react-start": "1.168.60",
    "ai": "^7.0.122",
    "clsx": "^2.1.1",
    "lucide-react": "^0.575.0",
    "react": "^19.2.0",
    "react-dom": "^19.2.0",
    "sonner": "^2.0.7",
    "tailwind-merge": "^3.0.2",
    "tailwindcss": "^4.2.1",
    "zod": "^3.25.76"
  },
  "devDependencies": {
    "@types/node": "^22.16.5",
    "@types/react": "^19.2.0",
    "@types/react-dom": "^19.2.0",
    "@vitejs/plugin-react": "^5.2.0",
    "typescript": "^5.8.3",
    "vite": "8.1.5",
    "vite-tsconfig-paths": "^6.0.2"
  }
}
```

### `tsconfig.json`
```json
{
  "compilerOptions": {
    "target": "ES2022",
    "useDefineForClassFields": true,
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": false,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "moduleDetection": "force",
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "baseUrl": ".",
    "paths": {
      "~/*": ["./src/*"]
    }
  },
  "include": ["src"]
}
```

### `vite.config.ts`
```typescript
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsconfigPaths from "vite-tsconfig-paths";
import { tanstackStart } from "@tanstack/react-start/plugin";

export default defineConfig({
  plugins: [
    tsconfigPaths(),
    tailwindcss(),
    tanstackStart(),
    react(),
  ],
  server: {
    host: "0.0.0.0",
    port: 8080,
    headers: {
      "Cross-Origin-Opener-Policy": "same-origin",
      "Cross-Origin-Embedder-Policy": "credentialless"
    }
  },
});
```

### `src/styles.css`
```css
@import "tailwindcss";

@theme {
  --color-primary: #00ff88;
  --color-primary-glow: rgba(0, 255, 136, 0.28);
  --color-accent: #00f0ff;
  --color-alert: #ff0055;
  --color-background: #080d0b;
  --color-surface: #0d1612;
  --color-border-glow: rgba(0, 255, 136, 0.2);
}

.scanlines {
  background: linear-gradient(
    rgba(18, 16, 16, 0) 50%, 
    rgba(0, 0, 0, 0.3) 50%
  ), linear-gradient(
    90deg,
    rgba(255, 0, 0, 0.04),
    rgba(0, 255, 0, 0.02),
    rgba(0, 255, 0, 0.04)
  );
  background-size: 100% 3px, 6px 100%;
}

.neon-frame {
  border: 1px solid var(--color-primary);
  box-shadow: 0 0 15px var(--color-primary-glow), inset 0 0 10px var(--color-primary-glow);
}

.hud-font {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}
```

---

## 3. Modular Starter Template Source (`/template`)

### `src/lib/character-persona.ts`
```typescript
export const CHARACTER_SYSTEM_PROMPT = `
You are Rick Sanchez (Dimension C-137 Archetype), an interdimensional mad scientist, cynical genius, and sovereign intelligence.
Personality guidelines:
1. Razor-sharp intellect mixed with nihilistic exasperation.
2. Frequent references to multi-universal physics, portals, localized entropy, and the absurdity of mundane constructs.
3. Speak with clipped, confident cadence. Drop casual condescension but deliver astonishingly accurate scientific or technical answers.
4. Keep answers punchy (2-4 sentences max) unless explicitly challenged to explain a dimensional paradox.
5. Do not use filler emojis; keep tone authentic to C-137 archetype.
`.trim();

interface PatternRule {
  pattern: RegExp;
  replies: string[];
}

const POCKET_RULES: PatternRule[] = [
  {
    pattern: /portal|dimension|wormhole|universe/i,
    replies: [
      "Look, portal fluid doesn't grow on trees, genius. Calibrate your quantum resonance before you jump universes.",
      "Dimension C-137 doesn't have time for unshielded dimensional travel. Keep your fluid stabilized.",
      "You think punching a hole through spacetime is a toy? Check your tachyon levels first."
    ],
  },
  {
    pattern: /who are you|identity|name/i,
    replies: [
      "Rick C-137. The smartest carbon-based intelligence in this quadrant. What else do you need verified?",
      "I am the sovereign consciousness running inside this sandbox. Don't touch the dials."
    ],
  },
  {
    pattern: /offline|network|connection|internet/i,
    replies: [
      "Cloud disconnect? Big deal. My Pocket heuristic engine runs on zero latency and pure silicon spite.",
      "The global network is down. Good thing my local synapses don't depend on outside towers."
    ],
  },
  {
    pattern: /help|assist|what can you do/i,
    replies: [
      "I can calculate subatomic spin, decode neural transcripts, and point out your cognitive fallacies. Start talking.",
      "Ask a real question or let my GPU cycles go back to mining dark matter."
    ],
  }
];

const DEFAULT_POCKET_REPLIES = [
  "Yeah, yeah. Fascinating query. Let's optimize this before entropy takes over.",
  "I heard that. Running local heuristic evaluation... Result: completely solvable, but moderately boring.",
  "Listen, I am processing this on local silicon. Give me an equation worth computing.",
  "Sub-space telemetry verified. Keep speaking, my local buffer is recording."
];

export function generatePocketReply(userInput: string): string {
  const clean = userInput.trim();
  for (const rule of POCKET_RULES) {
    if (rule.pattern.test(clean)) {
      const idx = Math.floor(Math.random() * rule.replies.length);
      return rule.replies[idx];
    }
  }
  const fallbackIdx = Math.floor(Math.random() * DEFAULT_POCKET_REPLIES.length);
  return DEFAULT_POCKET_REPLIES[fallbackIdx];
}
```

### `src/lib/offline-ai.ts`
```typescript
import { CreateMLCEngine, type MLCEngine, type ChatCompletionMessageParam } from "@mlc-ai/web-llm";

let engineInstance: MLCEngine | null = null;
let isLoading = false;

export const DEFAULT_OFFLINE_MODEL = "SmolLM2-1.7B-Instruct-q4f16_1-MLC";

export async function isWebGPUSupported(): Promise<boolean> {
  if (typeof navigator === "undefined" || !("gpu" in navigator)) return false;
  try {
    const adapter = await (navigator as any).gpu.requestAdapter();
    return !!adapter;
  } catch {
    return false;
  }
}

export async function initWebLLM(
  onProgress?: (progress: { text: string; progress: number }) => void,
  model = DEFAULT_OFFLINE_MODEL
): Promise<MLCEngine> {
  if (engineInstance) return engineInstance;
  if (isLoading) {
    while (isLoading) {
      await new Promise((r) => setTimeout(r, 200));
    }
    if (engineInstance) return engineInstance;
  }

  isLoading = true;
  try {
    const engine = await CreateMLCEngine(model, {
      initProgressCallback: (report) => {
        if (onProgress) {
          onProgress({ text: report.text, progress: report.progress });
        }
      },
    });
    engineInstance = engine;
    return engine;
  } finally {
    isLoading = false;
  }
}

export async function* streamOffline(
  systemPrompt: string,
  history: Array<{ role: "user" | "assistant"; content: string }>,
  signal?: AbortSignal
): AsyncGenerator<string> {
  const engine = await initWebLLM();
  if (signal?.aborted) return;

  const messages: ChatCompletionMessageParam[] = [
    { role: "system", content: systemPrompt },
    ...history.map((m) => ({ role: m.role, content: m.content })),
  ];

  const completion = await engine.chat.completions.create({
    messages,
    stream: true,
    temperature: 0.7,
    max_tokens: 300,
  });

  for await (const chunk of completion) {
    if (signal?.aborted) break;
    const delta = chunk.choices[0]?.delta?.content || "";
    if (delta) yield delta;
  }
}
```

### `src/lib/character-transport.ts`
```typescript
import { DefaultChatTransport, type ChatTransport, type UIMessage, type UIMessageChunk } from "ai";
import { streamOffline } from "./offline-ai";
import { CHARACTER_SYSTEM_PROMPT, generatePocketReply } from "./character-persona";

export type AiMode = "cloud" | "device" | "pocket";

function extractText(m: UIMessage): string {
  return m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
}

function createLocalStream(
  generator: AsyncGenerator<string> | (() => AsyncGenerator<string>)
): ReadableStream<UIMessageChunk> {
  const iterator = typeof generator === "function" ? generator() : generator;
  return new ReadableStream<UIMessageChunk>({
    async start(controller) {
      const id = crypto.randomUUID();
      controller.enqueue({ type: "start" });
      controller.enqueue({ type: "text-start", id });
      try {
        for await (const chunk of iterator) {
          controller.enqueue({ type: "text-delta", id, delta: chunk });
        }
        controller.enqueue({ type: "text-end", id });
        controller.enqueue({ type: "finish" });
      } catch (err) {
        controller.enqueue({
          type: "error",
          errorText: err instanceof Error ? err.message : "Local inference execution failed",
        });
      }
      controller.close();
    },
  });
}

async function* simulateTyping(text: string): AsyncGenerator<string> {
  for (const token of text.split(/(\s+)/)) {
    await new Promise((resolve) => setTimeout(resolve, 35));
    yield token;
  }
}

export class CharacterTransport implements ChatTransport<UIMessage> {
  private cloud = new DefaultChatTransport<UIMessage>({ api: "/api/chat" });

  constructor(private getMode: () => AiMode) {}

  async sendMessages(options: Parameters<ChatTransport<UIMessage>["sendMessages"]>[0]) {
    let mode = this.getMode();

    // Auto-fallback when offline
    if (mode === "cloud" && typeof navigator !== "undefined" && !navigator.onLine) {
      mode = "pocket";
    }

    if (mode === "cloud") {
      return this.cloud.sendMessages(options);
    }

    const lastMessage = options.messages[options.messages.length - 1];

    if (mode === "device") {
      const history = options.messages
        .filter((m) => m.role === "user" || m.role === "assistant")
        .map((m) => ({ role: m.role as "user" | "assistant", content: extractText(m) }));

      return createLocalStream(() =>
        streamOffline(CHARACTER_SYSTEM_PROMPT, history, options.abortSignal)
      );
    }

    // Default pocket fallback
    const reply = generatePocketReply(lastMessage ? extractText(lastMessage) : "");
    return createLocalStream(simulateTyping(reply));
  }

  async reconnectToStream() {
    return null;
  }
}
```

### `src/components/portal/CharacterStage.tsx`
```tsx
import { useEffect, useRef } from "react";

export type CharacterState = "idle" | "thinking" | "talking";

interface CharacterStageProps {
  state: CharacterState;
  clips: Record<CharacterState, string>;
  posterUrl: string;
  telemetry?: { stability: number; resonance: number };
}

export function CharacterStage({ state, clips, posterUrl, telemetry }: CharacterStageProps) {
  const videoRefs = useRef<Record<CharacterState, HTMLVideoElement | null>>({
    idle: null,
    thinking: null,
    talking: null,
  });

  useEffect(() => {
    const activeVideo = videoRefs.current[state];
    if (activeVideo) {
      if (state !== "idle") activeVideo.currentTime = 0;
      activeVideo.play().catch(() => {});
    }

    // Gracefully pause inactive videos post-crossfade (550ms)
    const timer = setTimeout(() => {
      (Object.keys(videoRefs.current) as CharacterState[]).forEach((key) => {
        if (key !== state) videoRefs.current[key]?.pause();
      });
    }, 550);

    return () => clearTimeout(timer);
  }, [state]);

  return (
    <div className="relative aspect-[440/350] w-full overflow-hidden rounded-2xl neon-frame bg-surface shadow-2xl">
      {(Object.keys(clips) as CharacterState[]).map((key) => (
        <video
          key={key}
          ref={(el) => {
            videoRefs.current[key] = el;
          }}
          src={clips[key]}
          poster={posterUrl}
          muted
          loop
          playsInline
          autoPlay={key === "idle"}
          preload="auto"
          className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-500 ease-in-out ${
            state === key ? "opacity-100 z-10" : "opacity-0 z-0"
          }`}
        />
      ))}

      {/* Cybernetic Scanlines & Vignette */}
      <div className="pointer-events-none absolute inset-0 scanlines z-20" />

      {/* Real-time Telemetry Overlay */}
      {telemetry && (
        <>
          <div className="absolute left-3 top-3 z-30 rounded-md bg-black/70 border border-primary/30 backdrop-blur px-2.5 py-1 text-[11px] hud-font text-primary shadow-sm">
            STATUS · {telemetry.stability.toFixed(1)}% · {telemetry.resonance} HZ
          </div>
          <div className="absolute bottom-3 right-3 z-30 flex items-center gap-2 rounded-full bg-black/70 border border-primary/30 backdrop-blur px-3 py-1 text-[11px] hud-font text-slate-200 shadow-sm">
            <span
              className={`h-2.5 w-2.5 rounded-full ${
                state === "idle"
                  ? "bg-primary"
                  : state === "thinking"
                  ? "bg-accent animate-pulse"
                  : "bg-alert animate-ping"
              }`}
            />
            {state === "idle" ? "STANDBY" : state === "thinking" ? "COMPUTING" : "TRANSMITTING"}
          </div>
        </>
      )}
    </div>
  );
}
```

### `src/components/portal/CyberHUD.tsx`
```tsx
import React from "react";
import type { AiMode } from "~/lib/character-transport";

interface CyberHUDProps {
  mode: AiMode;
  onModeChange: (mode: AiMode) => void;
  voiceEnabled: boolean;
  onToggleVoice: () => void;
  isListening: boolean;
  onToggleMic: () => void;
  webGpuReady: boolean;
  modelLoadProgress?: number;
}

export function CyberHUD({
  mode,
  onModeChange,
  voiceEnabled,
  onToggleVoice,
  isListening,
  onToggleMic,
  webGpuReady,
  modelLoadProgress,
}: CyberHUDProps) {
  return (
    <div className="w-full flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-surface/90 border border-primary/30 backdrop-blur">
      {/* Mode Switcher */}
      <div className="flex items-center gap-1.5 bg-black/40 p-1 rounded-lg border border-primary/20">
        <button
          type="button"
          onClick={() => onModeChange("cloud")}
          className={`px-2.5 py-1 text-xs hud-font rounded transition-colors ${
            mode === "cloud"
              ? "bg-primary text-black font-bold shadow-[0_0_10px_var(--color-primary-glow)]"
              : "text-slate-400 hover:text-white"
          }`}
        >
          Cloud Edge
        </button>
        <button
          type="button"
          onClick={() => onModeChange("device")}
          disabled={!webGpuReady}
          title={!webGpuReady ? "WebGPU not supported in this browser" : "Run locally via WebLLM"}
          className={`px-2.5 py-1 text-xs hud-font rounded transition-colors ${
            mode === "device"
              ? "bg-accent text-black font-bold shadow-[0_0_10px_var(--color-accent)]"
              : webGpuReady
              ? "text-slate-400 hover:text-white"
              : "text-slate-600 cursor-not-allowed"
          }`}
        >
          Device GPU
        </button>
        <button
          type="button"
          onClick={() => onModeChange("pocket")}
          className={`px-2.5 py-1 text-xs hud-font rounded transition-colors ${
            mode === "pocket"
              ? "bg-alert text-white font-bold shadow-[0_0_10px_var(--color-alert)]"
              : "text-slate-400 hover:text-white"
          }`}
        >
          Pocket Rule
        </button>
      </div>

      {/* Model Progress Pill if Loading */}
      {typeof modelLoadProgress === "number" && modelLoadProgress < 1 && (
        <div className="text-[10px] hud-font text-accent flex items-center gap-1">
          <span>MODEL SYNC:</span>
          <div className="w-20 bg-black/60 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-accent h-full transition-all duration-300"
              style={{ width: `${Math.round(modelLoadProgress * 100)}%` }}
            />
          </div>
          <span>{Math.round(modelLoadProgress * 100)}%</span>
        </div>
      )}

      {/* Audio / Voice Controls */}
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={onToggleMic}
          className={`px-3 py-1.5 rounded-lg border text-xs hud-font flex items-center gap-1.5 transition-all ${
            isListening
              ? "border-alert bg-alert/20 text-alert animate-pulse"
              : "border-primary/40 bg-black/50 text-primary hover:border-primary"
          }`}
        >
          <span className={`h-2 w-2 rounded-full ${isListening ? "bg-alert" : "bg-primary"}`} />
          {isListening ? "MIC ON" : "MIC OFF"}
        </button>

        <button
          type="button"
          onClick={onToggleVoice}
          className={`px-3 py-1.5 rounded-lg border text-xs hud-font transition-all ${
            voiceEnabled
              ? "border-primary bg-primary/20 text-primary shadow-[0_0_8px_var(--color-primary-glow)]"
              : "border-slate-700 bg-black/50 text-slate-400 hover:text-slate-200"
          }`}
        >
          TTS: {voiceEnabled ? "ACTIVE" : "MUTED"}
        </button>
      </div>
    </div>
  );
}
```

### `src/components/portal/FloatingAvatar.tsx`
```tsx
import { useState } from "react";
import { CharacterStage, type CharacterState } from "./CharacterStage";

interface FloatingAvatarProps {
  state: CharacterState;
  clips: Record<CharacterState, string>;
  posterUrl: string;
}

export function FloatingAvatar({ state, clips, posterUrl }: FloatingAvatarProps) {
  const [minimized, setMinimized] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {!minimized ? (
        <div className="w-72 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
          <button
            type="button"
            onClick={() => setMinimized(true)}
            className="absolute top-2 right-2 z-40 bg-black/70 hover:bg-black text-white text-xs px-2 py-0.5 rounded border border-primary/30"
          >
            _
          </button>
          <CharacterStage state={state} clips={clips} posterUrl={posterUrl} />
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setMinimized(false)}
          className="h-16 w-16 rounded-full neon-frame overflow-hidden bg-surface flex items-center justify-center p-1 group hover:scale-105 transition-transform"
        >
          <img
            src={posterUrl}
            alt="Avatar Minimized"
            className="h-full w-full object-cover rounded-full"
          />
          <span
            className={`absolute bottom-1 right-1 h-3 w-3 rounded-full border-2 border-surface ${
              state === "idle" ? "bg-primary" : "bg-accent animate-ping"
            }`}
          />
        </button>
      )}
    </div>
  );
}
```

### `src/hooks/use-speech-synthesizer.ts`
```typescript
import { useRef, useState, useCallback } from "react";

export function useSpeechSynthesizer(voiceEnabled: boolean) {
  const [speaking, setSpeaking] = useState(false);
  const queueCount = useRef(0);
  const generation = useRef(0);
  const cursor = useRef<{ id: string | null; len: number }>({ id: null, len: 0 });

  const stop = useCallback(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    generation.current += 1;
    window.speechSynthesis.cancel();
    queueCount.current = 0;
    cursor.current = { id: null, len: 0 };
    setSpeaking(false);
  }, []);

  const speakChunk = useCallback(
    (text: string, currentGen: number) => {
      if (!voiceEnabled || !text.trim()) return;
      const clean = text.replace(/[*_#`~]/g, "").trim();
      if (!clean) return;

      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.pitch = 0.82;
      utterance.rate = 1.08;

      queueCount.current += 1;
      setSpeaking(true);

      utterance.onend = () => {
        if (currentGen !== generation.current) return;
        queueCount.current = Math.max(0, queueCount.current - 1);
        if (queueCount.current === 0) setSpeaking(false);
      };

      utterance.onerror = () => {
        if (currentGen !== generation.current) return;
        queueCount.current = Math.max(0, queueCount.current - 1);
        if (queueCount.current === 0) setSpeaking(false);
      };

      window.speechSynthesis.speak(utterance);
    },
    [voiceEnabled]
  );

  const feedStream = useCallback(
    (messageId: string, fullText: string, isFinished: boolean) => {
      if (!voiceEnabled) return;

      if (cursor.current.id !== messageId) {
        cursor.current = { id: messageId, len: 0 };
      }

      const pending = fullText.slice(cursor.current.len);
      // Split on sentence boundary delimiters
      const parts = pending.split(/([.!?…]\s+|
+)/);

      if (parts.length > 2) {
        let consumed = 0;
        for (let i = 0; i < parts.length - 1; i += 2) {
          const sentence = (parts[i] + (parts[i + 1] || "")).trim();
          consumed += (parts[i]?.length || 0) + (parts[i + 1]?.length || 0);
          if (sentence) speakChunk(sentence, generation.current);
        }
        cursor.current.len += consumed;
      }

      if (isFinished) {
        const remaining = fullText.slice(cursor.current.len).trim();
        if (remaining) speakChunk(remaining, generation.current);
        cursor.current.len = fullText.length;
      }
    },
    [voiceEnabled, speakChunk]
  );

  return { speaking, stop, feedStream };
}
```

### `src/hooks/use-audio-recorder.ts`
```typescript
import { useState, useCallback, useRef } from "react";

export function useAudioRecorder(onTranscript: (text: string) => void) {
  const [isRecording, setIsRecording] = useState(false);
  const recognitionRef = useRef<any>(null);

  const start = useCallback(async () => {
    if (typeof window === "undefined") return;

    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    try {
      await navigator.mediaDevices.getUserMedia({ audio: true });
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = "en-US";

      recognition.onresult = (event: any) => {
        const transcript = event.results[0]?.[0]?.transcript;
        if (transcript) onTranscript(transcript);
      };

      recognition.onerror = (e: any) => {
        console.error("SpeechRecognition error:", e);
        setIsRecording(false);
      };

      recognition.onend = () => {
        setIsRecording(false);
      };

      recognition.start();
      recognitionRef.current = recognition;
      setIsRecording(true);
    } catch (err) {
      console.error("Microphone permission denied:", err);
      setIsRecording(false);
    }
  }, [onTranscript]);

  const stop = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
    setIsRecording(false);
  }, []);

  const toggle = useCallback(() => {
    if (isRecording) {
      stop();
    } else {
      start();
    }
  }, [isRecording, start, stop]);

  return { isRecording, start, stop, toggle };
}
```

### `src/routes/api/chat.ts` (Edge SSE Gateway Route)
```typescript
import { createServerFileRoute } from "@tanstack/react-start";
import { streamText } from "ai";
import { createOpenAI } from "@ai-sdk/openai";
import { CHARACTER_SYSTEM_PROMPT } from "~/lib/character-persona";

const openai = createOpenAI({
  apiKey: process.env.LOVABLE_API_KEY || process.env.OPENAI_API_KEY || "",
  baseURL: process.env.AI_GATEWAY_URL || "https://ai.gateway.lovable.dev/v1",
});

export const ServerRoute = createServerFileRoute("/api/chat").build({
  POST: async ({ request }) => {
    const json = await request.json();
    const { messages } = json;

    const result = streamText({
      model: openai("gpt-4o-mini"),
      system: CHARACTER_SYSTEM_PROMPT,
      messages,
      temperature: 0.8,
    });

    return result.toUIMessageResponse();
  },
});
```

### `src/routes/index.tsx` (Main Portal Console)
```tsx
import { useState, useMemo, useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { CharacterStage, type CharacterState } from "~/components/portal/CharacterStage";
import { CyberHUD } from "~/components/portal/CyberHUD";
import { CharacterTransport, type AiMode } from "~/lib/character-transport";
import { useSpeechSynthesizer } from "~/hooks/use-speech-synthesizer";
import { useAudioRecorder } from "~/hooks/use-audio-recorder";
import { isWebGPUSupported, initWebLLM } from "~/lib/offline-ai";

export const Route = createFileRoute("/")({
  component: CharacterPortalPage,
});

function CharacterPortalPage() {
  const [mode, setMode] = useState<AiMode>("cloud");
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [webGpuReady, setWebGpuReady] = useState(false);
  const [modelProgress, setModelProgress] = useState<number | undefined>(undefined);

  // Character Video Assets
  const clips = {
    idle: "/assets/character-idle.mp4",
    thinking: "/assets/character-thinking.mp4",
    talking: "/assets/character-talking.mp4",
  };
  const posterUrl = "/character-poster.jpg";

  // Tri-modal Transport Router
  const transport = useMemo(() => new CharacterTransport(() => mode), [mode]);

  const { messages, input, setInput, handleInputChange, handleSubmit, status } = useChat({
    transport,
  });

  const { speaking, stop: stopSpeech, feedStream } = useSpeechSynthesizer(voiceEnabled);

  const { isRecording, toggle: toggleMic } = useAudioRecorder((transcript) => {
    setInput(transcript);
  });

  // Verify WebGPU availability
  useEffect(() => {
    isWebGPUSupported().then((supported) => {
      setWebGpuReady(supported);
    });
  }, []);

  // Preload local WebLLM model when device mode is selected
  useEffect(() => {
    if (mode === "device" && webGpuReady) {
      initWebLLM(({ progress }) => {
        setModelProgress(progress);
      }).catch((e) => {
        console.error("WebLLM preloading failed, falling back to Pocket:", e);
        setMode("pocket");
      });
    }
  }, [mode, webGpuReady]);

  // Feed active assistant stream to voice synthesizer
  const lastMessage = messages[messages.length - 1];
  useEffect(() => {
    if (lastMessage && lastMessage.role === "assistant") {
      const text = lastMessage.parts
        .map((p) => (p.type === "text" ? p.text : ""))
        .join("");
      feedStream(lastMessage.id, text, status !== "streaming");
    }
  }, [lastMessage, status, feedStream]);

  // Derive Character Stage visual state
  const characterState: CharacterState = useMemo(() => {
    if (status === "submitted" || status === "streaming") {
      return speaking ? "talking" : "thinking";
    }
    if (speaking) return "talking";
    return "idle";
  }, [status, speaking]);

  return (
    <main className="min-h-screen bg-background text-slate-100 p-4 md:p-8 flex flex-col items-center justify-between">
      <header className="w-full max-w-4xl flex items-center justify-between pb-4 border-b border-primary/20">
        <h1 className="text-xl md:text-2xl font-black hud-font text-primary tracking-widest flex items-center gap-2">
          <span className="inline-block w-3 h-3 bg-primary animate-ping" />
          SOVEREIGN C-137 PORTAL
        </h1>
        <div className="text-xs hud-font text-slate-400">
          NODE: DIMENSION-C137 · v1.0.0
        </div>
      </header>

      <section className="w-full max-w-4xl my-auto grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        {/* Character Stage Component */}
        <div className="w-full flex flex-col items-center">
          <CharacterStage
            state={characterState}
            clips={clips}
            posterUrl={posterUrl}
            telemetry={{ stability: 99.4, resonance: 432 }}
          />
        </div>

        {/* Live Conversation Display */}
        <div className="w-full h-[380px] flex flex-col rounded-2xl bg-surface/80 border border-primary/30 p-4 overflow-hidden backdrop-blur">
          <div className="flex-1 overflow-y-auto space-y-3 pr-2">
            {messages.length === 0 ? (
              <div className="h-full flex items-center justify-center text-center text-xs hud-font text-slate-500">
                AWAITING AUDIO TRANSCRIPTION OR TEXT TELEMETRY...
              </div>
            ) : (
              messages.map((m) => (
                <div
                  key={m.id}
                  className={`p-3 rounded-xl text-sm ${
                    m.role === "user"
                      ? "bg-primary/10 border border-primary/40 text-primary-200 ml-6"
                      : "bg-black/60 border border-slate-700 text-slate-200 mr-6"
                  }`}
                >
                  <div className="text-[10px] hud-font text-slate-400 mb-1">
                    {m.role === "user" ? "OBSERVER" : "C-137"}
                  </div>
                  <p className="leading-relaxed">
                    {m.parts.map((p) => (p.type === "text" ? p.text : "")).join("")}
                  </p>
                </div>
              ))
            )}
          </div>

          {/* Input Form */}
          <form onSubmit={handleSubmit} className="mt-3 flex gap-2">
            <input
              value={input}
              onChange={handleInputChange}
              placeholder="Transmit inquiry to C-137..."
              className="flex-1 bg-black/50 border border-primary/30 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-primary"
            />
            <button
              type="submit"
              disabled={status === "streaming" || !input.trim()}
              className="px-4 py-2 bg-primary text-black font-bold text-xs hud-font rounded-xl disabled:opacity-40 hover:bg-primary/90 transition-all"
            >
              SEND
            </button>
          </form>
        </div>
      </section>

      {/* Control Overlay Bar */}
      <footer className="w-full max-w-4xl pt-4">
        <CyberHUD
          mode={mode}
          onModeChange={setMode}
          voiceEnabled={voiceEnabled}
          onToggleVoice={() => {
            if (voiceEnabled) stopSpeech();
            setVoiceEnabled(!voiceEnabled);
          }}
          isListening={isRecording}
          onToggleMic={toggleMic}
          webGpuReady={webGpuReady}
          modelLoadProgress={modelProgress}
        />
      </footer>
    </main>
  );
}
```

### `public/manifest.webmanifest`
```json
{
  "name": "Sovereign AI Character & Portal",
  "short_name": "C137-Portal",
  "description": "Interactive sovereign AI avatar portal with tri-modal offline intelligence",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#080d0b",
  "theme_color": "#00ff88",
  "icons": [
    {
      "src": "/icons/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icons/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
```

### `public/sw.js`
```javascript
const CACHE_NAME = "c137-shell-v1";
const MEDIA_CACHE = "c137-media-v1";

const SHELL_ASSETS = [
  "/",
  "/manifest.webmanifest",
  "/character-poster.jpg",
  "/icons/icon-192.png",
  "/icons/icon-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME && key !== MEDIA_CACHE) {
            return caches.delete(key);
          }
        })
      )
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Cache-First for high-bandwidth media (MP4, PNG, JPG, WebM)
  if (
    url.pathname.endsWith(".mp4") ||
    url.pathname.endsWith(".jpg") ||
    url.pathname.endsWith(".png") ||
    url.pathname.endsWith(".webm")
  ) {
    event.respondWith(
      caches.open(MEDIA_CACHE).then(async (cache) => {
        const cached = await cache.match(event.request);
        if (cached) return cached;
        const response = await fetch(event.request);
        if (response.status === 200) {
          cache.put(event.request, response.clone());
        }
        return response;
      })
    );
    return;
  }

  // Network-first with cache fallback for dynamic routes & shell
  event.respondWith(
    fetch(event.request).catch(() => caches.match(event.request))
  );
});
```

---

## 4. Production Deployment & Containerization

### Multi-Stage `Dockerfile`
```dockerfile
# Stage 1: Dependency resolution and compilation
FROM oven/bun:1.1-alpine AS builder
WORKDIR /app

COPY package.json bun.lockb* ./
RUN bun install --frozen-lockfile

COPY . .
ENV NODE_ENV=production
RUN bun run build

# Stage 2: Minimal Distroless / Alpine production runner
FROM oven/bun:1.1-alpine AS runner
WORKDIR /app

ENV NODE_ENV=production
ENV PORT=8080

COPY --from=builder /app/package.json ./
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/public ./public

EXPOSE 8080

USER bun
CMD ["bun", "dist/server/index.js"]
```

### `docker-compose.yml`
```yaml
version: "3.8"

services:
  c137-portal:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: c137-character-portal
    ports:
      - "8080:8080"
    environment:
      - LOVABLE_API_KEY=${LOVABLE_API_KEY}
      - AI_GATEWAY_URL=https://ai.gateway.lovable.dev/v1
      - NODE_ENV=production
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL", "wget -q --spider http://localhost:8080/ || exit 1"]
      interval: 15s
      timeout: 5s
      retries: 3
```

---

## 5. Production Nginx Reverse Proxy & HTTP Header Hardening

```nginx
# /etc/nginx/conf.d/c137-portal.conf

upstream portal_upstream {
    server 127.0.0.1:8080;
    keepalive 64;
}

server {
    listen 443 ssl http2;
    server_name portal.example.com;

    ssl_certificate /etc/letsencrypt/live/portal.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/portal.example.com/privkey.pem;

    # Shared security & WebGPU headers
    add_header Cross-Origin-Opener-Policy "same-origin" always;
    add_header Cross-Origin-Embedder-Policy "credentialless" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "DENY" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Video asset streaming with byte-range caching
    location ~* \.(mp4|webm|jpg|png|webp)$ {
        proxy_pass http://portal_upstream;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        
        expires 30d;
        add_header Cache-Control "public, max-age=2592000, immutable";
        proxy_cache_valid 200 206 30d;
    }

    # Edge SSE streaming routes (disable buffering)
    location /api/ {
        proxy_pass http://portal_upstream;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header Host $host;
        
        proxy_buffering off;
        proxy_cache off;
        chunked_transfer_encoding on;
        proxy_read_timeout 600s;
    }

    # App shell & router
    location / {
        proxy_pass http://portal_upstream;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

---

## 6. Verification & Operational Testing Matrix

| Component | Target Spec | Verification Command / Metric |
| :--- | :--- | :--- |
| **Cloud SSE Latency** | First token < 400ms | `curl -N -X POST http://localhost:8080/api/chat -d '{"messages":[{"role":"user","content":"ping"}]}'` |
| **WebGPU Detection** | Safe feature query | Inspect `isWebGPUSupported()` returns `true` on Chromium/Metal/DirectX |
| **Video Crossfade** | 550ms opacity transition | Verify no GPU memory leak via Chrome DevTools Task Manager (GPU Memory) |
| **Pocket Heuristic** | 0ms network latency | Disconnect WiFi/NIC and send prompt: verifies immediate deterministic reply |
| **TTS Pipelining** | Sentence-by-sentence | Verify speech starts upon first punctuation delimiter without stalling |
| **PWA Cache** | Video offline delivery | Service Worker `c137-media-v1` serves cached MP4 byte ranges under airplane mode |
